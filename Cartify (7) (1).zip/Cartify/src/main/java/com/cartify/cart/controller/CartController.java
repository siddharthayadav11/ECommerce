package com.cartify.cart.controller;

import com.cartify.cart.entities.Cart;
import com.cartify.cart.services.CartService;
import com.cartify.user.entities.Customer;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/cart")
public class CartController {

	@Autowired
	private CartService cartService;

	@GetMapping("/add/{productId}")
	@ResponseBody
	public String addToCart(@PathVariable int productId, HttpSession session) {
		Customer customer = (Customer) session.getAttribute("customer");
		if (customer == null) {
			return "redirect:/customer/login";
		}
		Cart cart = new Cart();
		cart.setCustomerId(customer.getId());
		cart.setProductId(productId);
		cart.setQuantity(1);
		cartService.addToCart(cart);
		return "success";
	}

	@GetMapping("/view")
	public String viewCart(Model model, HttpSession session) {
		Customer customer = (Customer) session.getAttribute("customer");
		if (customer == null) {
			return "redirect:/customer/login";
		}
		List<Cart> cartItems = cartService.getCartItemsByCustomerId(customer.getId());
		if (cartItems == null || cartItems.isEmpty()) {
			return "emptyCart";
		}
		double totalPrice = cartService.getTotalPrice(customer.getId());
		model.addAttribute("cartItems", cartItems);
		model.addAttribute("totalPrice", totalPrice);
		model.addAttribute("customerId", customer.getId());
		return "cart";
	}

	@PostMapping("/update")
	public String updateCartItem(@RequestParam int cartId, @RequestParam int quantity, HttpSession session) {
		Customer customer = (Customer) session.getAttribute("customer");
		if (customer == null) {
			return "redirect:/customer/login";
		}
		cartService.updateCartItem(cartId, quantity);
		return "redirect:/cart/view";
	}

	@PostMapping("/remove")
	public String removeCartItem(@RequestParam int cartId, HttpSession session) {
		Customer customer = (Customer) session.getAttribute("customer");
		if (customer == null) {
			return "redirect:/customer/login";
		}
		cartService.removeCartItem(cartId);

		List<Cart> cartItems = cartService.getCartItemsByCustomerId(customer.getId());
		if (cartItems == null || cartItems.isEmpty()) {
			return "emptyCart";
		}

		return "redirect:/cart/view";
	}

	@GetMapping("/checkout")
	public String checkout(HttpSession session, Model model) {
		Customer customer = (Customer) session.getAttribute("customer");
		if (customer == null) {
			return "redirect:/customer/login";
		}
		List<Cart> cartItems = cartService.getCartItemsByCustomerId(customer.getId());
		double totalPrice = cartService.getTotalPrice(customer.getId());
		model.addAttribute("cartItems", cartItems);
		model.addAttribute("totalPrice", totalPrice);
		model.addAttribute("customerId", customer.getId());
		return "checkout";
	}
}
