package com.cartify.cart.repository;

import com.cartify.cart.entities.Cart;
import java.util.List;

public interface CartDao {

	void addToCart(Cart cart);

	List<Cart> getCartItemsByCustomerId(int customerId);

	void updateCartItem(int cartId, int quantity);

	void removeCartItem(int cartId);

	double getTotalPrice(int customerId);

	void clearCart(int customerId);

}