package com.cartify.cart.repository;

import com.cartify.cart.entities.Cart;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Repository
public class CartDaoImpl implements CartDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	private static final String INSERT_CART_ITEM = "INSERT INTO Cart (customer_id, product_id, quantity) VALUES (?, ?, ?)";

	private static final String SELECT_CART_ITEMS_BY_CUSTOMER_ID = "SELECT \r\n" + "Cart.cart_id, \r\n"
			+ "Cart.customer_id, \r\n" + "Cart.product_id, \r\n" + "    Product.product_name AS product_name, \r\n"
			+ "Product.product_description AS product_description, \r\n"
			+ "Product.product_price AS product_price, \r\n" + "Cart.quantity, \r\n" + "Cart.added_date\r\n"
			+ "FROM \r\n" + "Cart\r\n" + "JOIN \r\n" + "Product ON Cart.product_id = Product.product_id\r\n"
			+ "WHERE \r\n" + "Cart.customer_id = ?";

	private static final String UPDATE_CART_ITEM = "UPDATE Cart SET quantity = ? WHERE cart_id = ?";

	private static final String DELETE_CART_ITEM = "DELETE FROM Cart WHERE cart_id = ?";

	private static final String SELECT_TOTAL_PRICE = "SELECT SUM(p.product_price * c.quantity) AS total_amount\r\n"
			+ "FROM Cart c\r\n" + "JOIN Product p ON c.product_id = p.product_id\r\n" + "WHERE c.customer_id = ?";

	private static final String DELETE_CART_ITEMS_BY_CUSTOMER_ID = "DELETE FROM Cart WHERE customer_id = ?";

	@Override
	public void clearCart(int customerId) {
		jdbcTemplate.update(DELETE_CART_ITEMS_BY_CUSTOMER_ID, customerId);
	}

	@Override
	public void addToCart(Cart cart) {
		jdbcTemplate.update(INSERT_CART_ITEM, cart.getCustomerId(), cart.getProductId(), cart.getQuantity());
	}

	@Override
	public List<Cart> getCartItemsByCustomerId(int customerId) {
		return jdbcTemplate.query(SELECT_CART_ITEMS_BY_CUSTOMER_ID, new CartRowMapper(), customerId);
	}

	@Override
	public void updateCartItem(int cartId, int quantity) {
		jdbcTemplate.update(UPDATE_CART_ITEM, quantity, cartId);
	}

	@Override
	public void removeCartItem(int cartId) {
		jdbcTemplate.update(DELETE_CART_ITEM, cartId);
	}

	@Override
	public double getTotalPrice(int customerId) {
		return jdbcTemplate.queryForObject(SELECT_TOTAL_PRICE, Double.class, customerId);
	}

	private static final class CartRowMapper implements RowMapper<Cart> {
		@Override
		public Cart mapRow(ResultSet rs, int rowNum) throws SQLException {
			Cart cart = new Cart();
			cart.setCartId(rs.getInt("cart_id"));
			cart.setCustomerId(rs.getInt("customer_id"));
			cart.setProductId(rs.getInt("product_id"));
			cart.setProductName(rs.getString("product_name"));
			cart.setProductDescription(rs.getString("product_description"));
			cart.setProductPrice(rs.getDouble("product_price"));
			cart.setQuantity(rs.getInt("quantity"));
			cart.setAddedDate(rs.getTimestamp("added_date"));
			return cart;
		}
	}
}