package com.cartify.cart.services;

import com.cartify.cart.entities.Cart;
import java.util.List;

public interface CartService {

	void addToCart(Cart cart);

	List<Cart> getCartItemsByCustomerId(int customerId);

	void updateCartItem(int cartId, int quantity);

	void removeCartItem(int cartId);

	double getTotalPrice(int customerId);

	void clearCart(int customerId);

}