package com.cartify.cart.services;

import com.cartify.cart.entities.Cart;
import com.cartify.cart.repository.CartDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CartServiceImpl implements CartService {

	@Autowired
	private CartDao cartDao;

	@Override
	public void addToCart(Cart cart) {
		cartDao.addToCart(cart);
	}

	@Override
	public List<Cart> getCartItemsByCustomerId(int customerId) {
		return cartDao.getCartItemsByCustomerId(customerId);
	}

	@Override
	public void updateCartItem(int cartId, int quantity) {
		cartDao.updateCartItem(cartId, quantity);
	}

	@Override
	public void removeCartItem(int cartId) {
		cartDao.removeCartItem(cartId);
	}

	@Override
	public double getTotalPrice(int customerId) {
		return cartDao.getTotalPrice(customerId);
	}

	@Override
	public void clearCart(int customerId) {
		cartDao.clearCart(customerId);
	}
}