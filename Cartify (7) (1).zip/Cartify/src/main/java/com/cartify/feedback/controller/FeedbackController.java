package com.cartify.feedback.controller;

import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.cartify.feedback.entities.Feedback;
import com.cartify.feedback.services.FeedbackService;
import com.cartify.user.entities.Customer;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/feedback")
public class FeedbackController {

    @Autowired
    FeedbackService feedbackService;

    @GetMapping("/submit")
    public String openFeedbackPage() {
        return "feedback/submitFeedback";
    }

    @PostMapping("/submit")
    public String submitFeedback(@ModelAttribute Feedback feedback, HttpSession session, Model model) {
        String message;

        try {
            // Step 1: Retrieve the logged-in customer from the session
            Customer loggedInCustomer = (Customer) session.getAttribute("customer");

            if (loggedInCustomer == null) {
                // If no customer is logged in, redirect to the login page
                return "redirect:/customer/login";
            }

            // Step 2: Set the customer ID in the feedback object
            feedback.setCustomerId(loggedInCustomer.getId());

            // Step 3: Set submission date dynamically
            feedback.setSubmissionDate(new Date(System.currentTimeMillis()));

            // Step 4: Save feedback using the service
            feedbackService.submitFeedback(feedback);

            // Step 5: Success message
            message = "Thank you for your feedback!";
            model.addAttribute("success", true);
        } catch (SQLException e) {
            // Step 6: Handle errors
            message = "Failed to submit feedback. Please try again later.";
            model.addAttribute("success", false);
            e.printStackTrace(); // Log exception for debugging
        }

        // Step 7: Add message to the model
        model.addAttribute("message", message);

        // Step 8: Return feedback submission page
        return "feedback/submitFeedback";
    }

    
    
    

    @GetMapping("/all")
    public String viewAllFeedbacks(Model model) {
        try {
            List<Feedback> feedbackList = feedbackService.getAllFeedbacks();
            model.addAttribute("feedbackList", feedbackList);
            return "feedback/viewFeedbacks";
        } catch (Exception e) {
            e.printStackTrace();
            model.addAttribute("error", "Failed to fetch feedbacks. Please try again.");
            return "error";
        }
    }

    @GetMapping("/delete/{feedbackId}")
    public String deleteFeedback(@PathVariable int feedbackId, Model model) {
        try {
            feedbackService.deleteFeedback(feedbackId);
            model.addAttribute("message", "Feedback deleted successfully!");
        } catch (Exception e) {
            e.printStackTrace();
            model.addAttribute("message", "Error occurred while deleting feedback.");
        }
        return "redirect:/feedback/all";
    }


}
