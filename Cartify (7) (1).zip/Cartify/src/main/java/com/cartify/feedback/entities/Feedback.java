package com.cartify.feedback.entities;

import java.sql.Date;

public class Feedback {
	private int feedbackId;
	private int customerId;
	private double rating;
	private String review;
	private Date submissionDate;
	public Feedback() {
		super();
	}

	
	
	public Feedback(int feedbackId, int customerId, int productId, double rating, String review, Date submissionDate) {
		super();
		this.feedbackId = feedbackId;
		this.customerId = customerId;
		this.rating = rating;
		this.review = review;
		this.submissionDate = submissionDate;
	}
	public Feedback(int customerId, int productId, double rating, String review, Date submissionDate) {
		super();
		this.customerId = customerId;
		this.rating = rating;
		this.review = review;
	}
	
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public double getRating() {
		return rating;
	}
	public void setRating(double rating) {
		this.rating = rating;
	}
	public String getReview() {
		return review;
	}
	public void setReview(String review) {
		this.review = review;
	}

	public Date getSubmissionDate() {
		return submissionDate;
	}

	public void setSubmissionDate(Date submissionDate) {
		this.submissionDate = submissionDate;
	}

	public int getFeedbackId() {
		return feedbackId;
	}

	public void setFeedbackId(int feedbackId) {
		this.feedbackId = feedbackId;
	}

	@Override
	public String toString() {
		return "Feedback [feedbackId=" + feedbackId + ", customerId=" + customerId + ", rating=" + rating + ", review="
				+ review + ", submissionDate=" + submissionDate + "]";
	}

}
