
package com.cartify.feedback.repository;

import java.sql.Date;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.cartify.feedback.entities.Feedback;

@Repository
public class FeedbackDaoImpl implements FeedbackDao {

    @Autowired
    JdbcTemplate jdbcTemplate;
    
    public JdbcTemplate getJdbcTemplate() {
        return jdbcTemplate;
    }
    
    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
    	this.jdbcTemplate = jdbcTemplate;
    }
    
    @Override
    public int submitFeedback(Feedback feedback) throws SQLException {
        final String INSERT_QUERY = "INSERT INTO feedback(customer_id, rating, review) VALUES(?,?,?)";
        return jdbcTemplate.update(INSERT_QUERY, feedback.getCustomerId(), feedback.getRating(), feedback.getReview());
    }


    @Override
    public List<Feedback> getAllFeedbacks() {
        final String SELECT_QUERY = "SELECT * FROM feedback";
        return jdbcTemplate.query(SELECT_QUERY, new FeedbackRowMapper());
    }


    @Override
    public Feedback getFeedbackById(int feedbackId) {
        final String SELECT_QUERY = "SELECT * FROM feedback WHERE feedback_id = ?";
        return jdbcTemplate.queryForObject(SELECT_QUERY, new FeedbackRowMapper(), feedbackId);
    }

    @Override
    public void deleteFeedback(int feedbackId) {
        final String DELETE_QUERY = "DELETE FROM feedback WHERE feedback_id = ?";
        jdbcTemplate.update(DELETE_QUERY, feedbackId);
    }

}
