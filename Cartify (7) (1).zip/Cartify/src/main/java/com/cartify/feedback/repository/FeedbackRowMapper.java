package com.cartify.feedback.repository;
 
import java.sql.ResultSet;

import java.sql.SQLException;
 
import org.springframework.jdbc.core.RowMapper;
 
import com.cartify.feedback.entities.Feedback;
 
public class FeedbackRowMapper implements RowMapper<Feedback> {
 
	@Override
    public Feedback mapRow(ResultSet rs, int rowNum) throws SQLException {
        Feedback feedback = new Feedback();
        feedback.setFeedbackId(rs.getInt("feedback_id"));
        feedback.setCustomerId(rs.getInt("customer_id"));
        feedback.setRating(rs.getDouble("rating"));
        feedback.setReview(rs.getString("review"));
        feedback.setSubmissionDate(rs.getDate("submission_date"));
        return feedback;
    }

}