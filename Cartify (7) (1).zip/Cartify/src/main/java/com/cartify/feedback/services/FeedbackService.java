package com.cartify.feedback.services;

import java.sql.SQLException;
import java.util.List;

import com.cartify.feedback.entities.Feedback;

public interface FeedbackService {
	
	int submitFeedback(Feedback feedback) throws SQLException;

	List<Feedback> getAllFeedbacks();

	Feedback getFeedbackById(int feedbackId);

	void deleteFeedback(int feedbackId);

}
