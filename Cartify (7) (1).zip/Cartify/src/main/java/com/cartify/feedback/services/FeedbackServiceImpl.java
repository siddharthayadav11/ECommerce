package com.cartify.feedback.services;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cartify.feedback.entities.Feedback;
import com.cartify.feedback.repository.FeedbackDao;

@Service
public class FeedbackServiceImpl implements FeedbackService {

    @Autowired
    FeedbackDao feedbackDao;
    
    @Override
    public int submitFeedback(Feedback feedback) throws SQLException {
        return feedbackDao.submitFeedback(feedback);
    }

    @Override
    public List<Feedback> getAllFeedbacks() {
        return feedbackDao.getAllFeedbacks();
    }


    @Override
    public Feedback getFeedbackById(int feedbackId) {
        return feedbackDao.getFeedbackById(feedbackId);
    }

    @Override
    public void deleteFeedback(int feedbackId) {
        feedbackDao.deleteFeedback(feedbackId);
    }
}
