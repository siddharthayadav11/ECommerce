package com.cartify.inventory.controller;

public class InventoryController {

}
