package com.cartify.inventory.entities;

public class Inventory {

}
