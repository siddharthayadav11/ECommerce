package com.cartify.inventory.repository;

public interface InventoryDao {

}
