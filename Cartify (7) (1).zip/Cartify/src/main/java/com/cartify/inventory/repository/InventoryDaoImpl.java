package com.cartify.inventory.repository;

public class InventoryDaoImpl {

}
