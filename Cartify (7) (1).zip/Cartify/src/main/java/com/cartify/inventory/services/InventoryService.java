package com.cartify.inventory.services;

public interface InventoryService {

}
