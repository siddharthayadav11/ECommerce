package com.cartify.inventory.services;

public class InventoryServiceImpl {

}
