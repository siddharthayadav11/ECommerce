package com.cartify.order.controller;

import com.cartify.cart.entities.Cart;
import com.cartify.cart.services.CartService;
import com.cartify.order.entities.Order;
import com.cartify.order.entities.ShippingAddress;
import com.cartify.order.services.OrderService;
import com.cartify.payment.entities.Payment;
import com.cartify.payment.services.PaymentService;
import com.cartify.user.entities.Admin;
import com.cartify.user.entities.Customer;
import com.cartify.user.entities.SubAdmin;

import jakarta.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.sql.Timestamp;
import java.util.List;

@Controller
@RequestMapping("/order")
public class OrderController {

	@Autowired
	private OrderService orderService;

	@Autowired
	private CartService cartService;
	
	@Autowired
	private PaymentService paymentService;

	@PostMapping("/create")
	public String createOrder(@RequestParam int customerId, @RequestParam double totalPrice) {
		Order order = new Order();
		order.setCustomerId(customerId);
		order.setTotalPrice(totalPrice);
		order.setOrderDate(new Timestamp(System.currentTimeMillis()));
		orderService.createOrder(order, null);
		return "redirect:/order/view?customerId=" + customerId;
	}

	@GetMapping("/view")
	public String viewOrders(@RequestParam int customerId, Model model) {
		List<Order> orders = orderService.getOrdersByCustomerId(customerId);
		model.addAttribute("orders", orders);
		return "orders";
	}

	@GetMapping("/checkout")
	public String checkout(@RequestParam int customerId, Model model) {
		List<Cart> cartItems = cartService.getCartItemsByCustomerId(customerId);
		double totalPrice = cartService.getTotalPrice(customerId);
		model.addAttribute("cartItems", cartItems);
		model.addAttribute("totalPrice", totalPrice);
		model.addAttribute("customerId", customerId);
		return "checkout";
	}

	@PostMapping("/placeOrder")
	public String placeOrder(
	        @RequestParam int customerId,
	     
	        @RequestParam String street,
	        @RequestParam String city,
	        @RequestParam("hiddenState") String state,
	        @RequestParam String postalCode,
	        @RequestParam String country,
	        @RequestParam String razorpay_payment_id,
	        @RequestParam String razorpay_order_id,
	        @RequestParam String razorpay_signature,
	        Model model) {

	    double totalPrice = cartService.getTotalPrice(customerId);

	    // Save order details
	    Order order = new Order();
	    order.setCustomerId(customerId);
	    order.setTotalPrice(totalPrice);
	   
	    
	    order.setOrderDate(new Timestamp(System.currentTimeMillis()));

	    ShippingAddress shippingAddress = new ShippingAddress();
	    shippingAddress.setCustomerId(customerId);
	    shippingAddress.setStreet(street);
	    shippingAddress.setCity(city);
	    shippingAddress.setState(state);
	    shippingAddress.setPostalCode(postalCode);
	    shippingAddress.setCountry(country);

	    orderService.createOrder(order, shippingAddress);
	    

	    // Save payment details
	    Payment payment = new Payment();
	    payment.setPaymentId(razorpay_payment_id);
	    
	    payment.setSignature(razorpay_signature);
	    payment.setCustomerId(customerId);
	    payment.setAmount(totalPrice);
	    payment.setStatus("SUCCESS");

	    paymentService.savePayment(payment);

	    // Clear cart
	    cartService.clearCart(customerId);

	    // Add attributes for confirmation page
	    model.addAttribute("order", order);
	    model.addAttribute("payment", payment);

	    return "orderConfirmation";
	}


	
	
	@GetMapping("/details")
	public String orderDetails(@RequestParam int orderId, Model model) {
		Order order = orderService.getOrderById(orderId);
		List<ShippingAddress> shippingAddresses = orderService.getShippingAddressesByCustomerId(order.getCustomerId());
		model.addAttribute("order", order);
		model.addAttribute("shippingAddresses", shippingAddresses);
		return "OrderDetails";
	}
	
	@GetMapping("/viewOrders")
	public String getAllOrders(Model model, HttpSession session) {
		Customer customer = (Customer) session.getAttribute("customer");
		Admin loggedInAdmin = (Admin) session.getAttribute("loggedInAdmin");
		SubAdmin loggedInSubAdmin = (SubAdmin) session.getAttribute("loggedInSubAdmin");

		// If neither customer, loggedInAdmin, nor loggedInSubAdmin is present, redirect
		// to login
		if (customer == null && loggedInAdmin == null && loggedInSubAdmin == null) {
			return "redirect:/customer/login";
		}

		// Assuming roleId check is only for customers
		if (customer != null) {
			int roleId = customer.getRole();
			if (roleId != 1 && roleId != 2) {
				return "notAuthorized";
			}
		}

		List<Order> orders = orderService.getAllOrders();
		System.out.println("Displaying all orders");
		model.addAttribute("orders", orders);
		return "ordersAdmin";
	}

	@PostMapping("/update")
	public String updateOrderStatus(@RequestParam("orderId") int orderId,
			@RequestParam("orderStatus") String orderStatus, HttpSession session) {
		Customer customer = (Customer) session.getAttribute("customer");
		Admin loggedInAdmin = (Admin) session.getAttribute("loggedInAdmin");
		SubAdmin loggedInSubAdmin = (SubAdmin) session.getAttribute("loggedInSubAdmin");

		// If neither customer, loggedInAdmin, nor loggedInSubAdmin is present, redirect
		// to login
		if (customer == null && loggedInAdmin == null && loggedInSubAdmin == null) {
			return "redirect:/customer/login";
		}

		// Assuming roleId check is only for customers
		if (customer != null) {
			int roleId = customer.getRole();
			if (roleId != 1 && roleId != 2) {
				return "notAuthorized";
			}
		}

		orderService.updateOrderStatus(orderId, orderStatus);
		System.out.println("Updated order ID " + orderId + " to status " + orderStatus);
		return "redirect:/order/viewOrders";
	}


}