package com.cartify.order.repository;

import com.cartify.order.entities.Order;
import java.util.List;

public interface OrderDao {

	void createOrder(Order order);

	Order getOrderById(int orderId);

	List<Order> getOrdersByCustomerId(int customerId);

	List<Order> getAllOrders();

	int updateOrderStatus(int orderId, String orderStatus);
}