package com.cartify.order.repository;

import com.cartify.order.entities.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Repository
public class OrderDaoImpl implements OrderDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	private static final String INSERT_ORDER = "INSERT INTO Orders (customer_id, total_price, order_status, order_date) VALUES (?, ?, ?, ?)";
	private static final String SELECT_ORDER_BY_ID = "SELECT * FROM Orders WHERE order_id = ?";
	private static final String SELECT_ORDERS_BY_CUSTOMER_ID = "SELECT * FROM Orders WHERE customer_id = ?";
	private static final String SELECT_ALL_ORDERS = "SELECT * FROM Orders";
	private static final String UPDATE_ORDER_STATUS = "UPDATE Orders SET order_status = ? WHERE order_id = ?";

	@Override
	public void createOrder(Order order) {
		KeyHolder keyHolder = new GeneratedKeyHolder();
		jdbcTemplate.update(new PreparedStatementCreator() {
			@Override
			public PreparedStatement createPreparedStatement(Connection connection) throws SQLException {
				PreparedStatement ps = connection.prepareStatement(INSERT_ORDER, new String[] { "order_id" });
				ps.setInt(1, order.getCustomerId());
				ps.setDouble(2, order.getTotalPrice());
				ps.setString(3, order.getOrderStatus());
				ps.setTimestamp(4, order.getOrderDate());
				return ps;
			}
		}, keyHolder);
		order.setOrderId(keyHolder.getKey().intValue());
		System.out.println("Created order: " + order);
	}

	@Override
	public Order getOrderById(int orderId) {
		Order order = jdbcTemplate.queryForObject(SELECT_ORDER_BY_ID, new OrderRowMapper(), orderId);
		System.out.println("Fetched order: " + order);
		return order;
	}

	@Override
	public List<Order> getOrdersByCustomerId(int customerId) {
		List<Order> orders = jdbcTemplate.query(SELECT_ORDERS_BY_CUSTOMER_ID, new OrderRowMapper(), customerId);
		System.out.println("Fetched " + orders.size() + " orders for customer ID " + customerId);
		return orders;
	}

	@Override
	public List<Order> getAllOrders() {
		List<Order> orders = jdbcTemplate.query(SELECT_ALL_ORDERS, new OrderRowMapper());
		System.out.println("Fetched " + orders.size() + " orders from the database");
		return orders;
	}

	@Override
	public int updateOrderStatus(int orderId, String orderStatus) {
		int rows = jdbcTemplate.update(UPDATE_ORDER_STATUS, orderStatus, orderId);
		System.out.println("Updated status of order ID " + orderId + " to " + orderStatus);
		return rows;
	}

	private static final class OrderRowMapper implements RowMapper<Order> {
		@Override
		public Order mapRow(ResultSet rs, int rowNum) throws SQLException {
			Order order = new Order();
			order.setOrderId(rs.getInt("order_id"));
			order.setCustomerId(rs.getInt("customer_id"));
			order.setTotalPrice(rs.getDouble("total_price"));
			order.setOrderStatus(rs.getString("order_status"));
			order.setOrderDate(rs.getTimestamp("order_date"));
			return order;
		}
	}
}
