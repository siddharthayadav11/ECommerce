package com.cartify.order.repository;

import java.util.List;
import java.util.Optional;

import com.cartify.order.entities.ShippingAddress;

public interface ShippingAddressDao {

	void saveShippingAddress(ShippingAddress shippingAddress);

	List<ShippingAddress> getShippingAddressesByCustomerId(int customerId);

	Optional<ShippingAddress> findAddressByID(int customerId);

	void deleteAddressById(int customerId);
}
