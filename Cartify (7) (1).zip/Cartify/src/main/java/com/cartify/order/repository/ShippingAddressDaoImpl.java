package com.cartify.order.repository;

import com.cartify.order.entities.ShippingAddress;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

@Repository
public class ShippingAddressDaoImpl implements ShippingAddressDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	private static final String INSERT_SHIPPING_ADDRESS = "INSERT INTO ShippingAddress (customer_id, street, city, state, postal_code, country) VALUES (?, ?, ?, ?, ?, ?)";

	private static final String SELECT_SHIPPING_ADDRESS_BY_CUSTOMER_ID = "SELECT * FROM ShippingAddress WHERE customer_id = ?";

	@Override
	public void saveShippingAddress(ShippingAddress shippingAddress) {
		jdbcTemplate.update(INSERT_SHIPPING_ADDRESS, shippingAddress.getCustomerId(), shippingAddress.getStreet(),
				shippingAddress.getCity(), shippingAddress.getState(), shippingAddress.getPostalCode(),
				shippingAddress.getCountry());

	}

	@Override
	public List<ShippingAddress> getShippingAddressesByCustomerId(int customerId) {
		return jdbcTemplate.query(SELECT_SHIPPING_ADDRESS_BY_CUSTOMER_ID, new ShippingAddressRowMapper(), customerId);
	}

	// new
	@Override
	public Optional<ShippingAddress> findAddressByID(int customerId) {
		String sql = "SELECT * FROM shippingaddress WHERE customer_id = ?";
		try {
			ShippingAddress address = jdbcTemplate.queryForObject(sql, new ShippingAddressRowMapper(), customerId);

			return Optional.of(address);
		} catch (Exception e) {
			return Optional.empty();
		}
	}

	@Override
	public void deleteAddressById(int customerId) {
		String sql = "DELETE FROM shippingaddress WHERE customer_id = ?";
		jdbcTemplate.update(sql, customerId);

	}

	private static final class ShippingAddressRowMapper implements RowMapper<ShippingAddress> {
		@Override
		public ShippingAddress mapRow(ResultSet rs, int rowNum) throws SQLException {
			ShippingAddress address = new ShippingAddress();
			address.setAddressId(rs.getInt("address_id"));
			address.setCustomerId(rs.getInt("customer_id"));
			address.setStreet(rs.getString("street"));
			address.setCity(rs.getString("city"));
			address.setState(rs.getString("state"));
			address.setPostalCode(rs.getString("postal_code"));
			address.setCountry(rs.getString("country"));
			return address;
		}
	}

}