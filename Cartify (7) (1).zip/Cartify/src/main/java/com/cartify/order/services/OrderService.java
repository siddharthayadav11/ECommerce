package com.cartify.order.services;

import com.cartify.order.entities.Order;
import com.cartify.order.entities.ShippingAddress;

import java.util.List;

public interface OrderService {

	void createOrder(Order order, ShippingAddress shippingAddress);

	Order getOrderById(int orderId);

	List<Order> getOrdersByCustomerId(int customerId);

	List<ShippingAddress> getShippingAddressesByCustomerId(int customerId);
	
	List<Order> getAllOrders();

	int updateOrderStatus(int orderId, String orderStatus);
}