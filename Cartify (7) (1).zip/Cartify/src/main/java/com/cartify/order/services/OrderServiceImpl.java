package com.cartify.order.services;

import com.cartify.order.entities.Order;
import com.cartify.order.entities.ShippingAddress;
import com.cartify.order.repository.OrderDao;
import com.cartify.order.repository.ShippingAddressDao;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class OrderServiceImpl implements OrderService {

	@Autowired
	private OrderDao orderDao;

	@Autowired
	private ShippingAddressDao shippingAddressDao;

	@Override
	@Transactional
	public void createOrder(Order order, ShippingAddress shippingAddress) {

		Optional<ShippingAddress> address = shippingAddressDao.findAddressByID(shippingAddress.getCustomerId());

		if (address.isPresent()) {
			ShippingAddress existingAddress = address.get();
			shippingAddressDao.deleteAddressById(existingAddress.getCustomerId());
		}

		shippingAddressDao.saveShippingAddress(shippingAddress);
		orderDao.createOrder(order);
	}

	@Override
	public Order getOrderById(int orderId) {
		return orderDao.getOrderById(orderId);
	}

	@Override
	public List<Order> getOrdersByCustomerId(int customerId) {
		return orderDao.getOrdersByCustomerId(customerId);
	}

	@Override
	public List<ShippingAddress> getShippingAddressesByCustomerId(int customerId) {
		return shippingAddressDao.getShippingAddressesByCustomerId(customerId);
	}

	@Override
	public List<Order> getAllOrders() {
		return orderDao.getAllOrders();
	}

	@Override
	public int updateOrderStatus(int orderId, String orderStatus) {
		return orderDao.updateOrderStatus(orderId, orderStatus);
	}
}
