package com.cartify.payment.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cartify.payment.entities.Payment;
import com.cartify.payment.repository.PaymentDao;

@RestController  // Add this to mark the class as a REST Controller
public class PaymentController {

   PaymentDao paymentDao;

    // Use appropriate @RequestParam for the incoming values
    @PostMapping("/savePayment")
    public ResponseEntity<String> savePayment(@RequestParam String razorpay_payment_id
                                             ) {

        // Save the payment details in the database
        Payment payment = new Payment();
        payment.setPaymentId(razorpay_payment_id);
       
        

        // Call the DAO to save the payment details
        paymentDao.savePayment(payment);

        // Return a success response
        return ResponseEntity.ok("Payment saved successfully");
    }
}

