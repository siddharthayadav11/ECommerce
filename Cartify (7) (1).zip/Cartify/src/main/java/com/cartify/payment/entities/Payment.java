package com.cartify.payment.entities;

public class Payment {
    private String paymentId;     // Payment ID from Razorpay
    private Long orderId;         // Order ID, linked to the Order table (auto-generated)
    private String signature;     // Razorpay Signature
    private int customerId;       // Customer ID related to the order
    private double amount;        // Amount of the payment
    private String status;        // Payment status (Pending, Completed, Failed, etc.)

    // Getters and Setters
    public String getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(String paymentId) {
        this.paymentId = paymentId;
    }

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    // Constructor
    public Payment(String paymentId, Long orderId, String signature, int customerId, double amount, String status) {
        this.paymentId = paymentId;
        this.orderId = orderId;
        this.signature = signature;
        this.customerId = customerId;
        this.amount = amount;
        this.status = status;
    }

    // Default Constructor
    public Payment() {
    }

    // toString() method
    @Override
    public String toString() {
        return "Payment [paymentId=" + paymentId + ", orderId=" + orderId + ", signature=" + signature + 
               ", customerId=" + customerId + ", amount=" + amount + ", status=" + status + "]";
    }
}
