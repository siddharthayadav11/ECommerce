package com.cartify.payment.repository;

import com.cartify.payment.entities.Payment;

public interface PaymentDao {

	 public void savePayment(Payment payment);
}
