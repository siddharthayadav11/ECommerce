package com.cartify.payment.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.cartify.payment.entities.Payment;


@Repository
public class PaymentDaoImpl implements PaymentDao{
	
	 @Autowired
	    private JdbcTemplate jdbcTemplate;

	    public void savePayment(Payment payment) {
	        String sql = "INSERT INTO payments (payment_id, customer_id, amount, status) VALUES (?, ?, ?, ?)";
	        jdbcTemplate.update(sql, payment.getPaymentId(),
	                payment.getCustomerId(), payment.getAmount(), payment.getStatus());
	    }

}
