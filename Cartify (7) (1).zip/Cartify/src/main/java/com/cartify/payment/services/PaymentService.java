package com.cartify.payment.services;

import org.springframework.stereotype.Service;

import com.cartify.payment.entities.Payment;



public interface PaymentService {
	
	   public void savePayment(Payment payment);

}
