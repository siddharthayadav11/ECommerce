package com.cartify.payment.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cartify.payment.entities.Payment;
import com.cartify.payment.repository.PaymentDao;



@Service
public class PaymentServiceImpl implements PaymentService {
	
	
	@Autowired
    private PaymentDao paymentDao;

    public void savePayment(Payment payment) {
        paymentDao.savePayment(payment);
    }
}


