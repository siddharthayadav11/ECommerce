package com.cartify.product.controller;

import java.io.IOException;

import java.sql.SQLException;
import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cartify.product.entities.Categories;
import com.cartify.product.services.CategoriesService;

@Controller
@RequestMapping("/customer")
public class CategoriesController {
    Categories categories;
    @Autowired
    CategoriesService categoriesService;
    
    @GetMapping("/")
    public String openCategoriesPage() {
        return "index";
    }

    @GetMapping("/openElectronicsPage")
    public String electronicsPage() {
        System.out.println("electronicsPage method called");
        return "customer/electronics";
    }
    
    @GetMapping("/openAccessoriesPage")
    public String accessoriesPage() {
        return "customer/accessories";
    }
    
    @GetMapping("/openClothingPage")
    public String clothingPage() {
        return "customer/clothing";
    }
    
    @GetMapping("/openCategoriesPage")
    public String openingCategoriesPage(Model model) {
        System.out.println("\n Inside Categories page");
        
        List<Categories> categoriesList = categoriesService.fetchAllCategories();
        model.addAttribute("ListofCategories", categoriesList);
        
        return "customer/viewPage";
    }
    
    @GetMapping("/addCategoryPage")
    public String addCategoryPage()
    {
    	return "customer/addCategories";
    }
    
    @GetMapping("/manageCategory")
    public String manageCategory() {
    	return "customer/manageCategory";
    }
    
    @PostMapping("/addCategory")
	public ModelAndView addCategory(@ModelAttribute Categories categories, ModelAndView mView) {
		String message = "";
		int result = 0;

		// Check if category already exists
		if (categoriesService.isCategoryExists(categories.getCategoryName())) {
			message = "Category with this name already exists. Please choose a different name.";
			mView.addObject("success", false);
		} else {
			try {
				result = categoriesService.addCategories(categories);
				if (result > 0) {
					message = "Category Added Successfully";
					mView.addObject("success", true);
				} else {
					message = "Category Not Added. Please try Again";
					mView.addObject("success", false);
				}
			} catch (IOException | SQLException e) {
				e.printStackTrace();
				message = "Error occurred while adding category. Please try again.";
				mView.addObject("success", false);
			}
		}

		mView.setViewName("customer/addCategories");
		mView.addObject("message", message);
		return mView;
	}
    
    @GetMapping("/viewCategories")
    public String viewCategoriesPage(Model model) {
        List<Categories> categoriesList = categoriesService.fetchAllCategories();
        model.addAttribute("ListofCategories", categoriesList);
        return "customer/viewPage";  // Name of your JSP page
    }
    @GetMapping("/updateCategoryPage")
	public String openCategoryUpdatePage(@RequestParam("category") String categoryName, Model model) {

		Categories category = categoriesService.findCategoryByName(categoryName);

		model.addAttribute("category", category);
		return "customer/updateCategory";
	}
    
    

	@PostMapping("/updateCategory")
	public ModelAndView updateCategory(@ModelAttribute Categories category, ModelAndView mView) {
		String message;
		boolean success;
		try {
			boolean isUpdated = categoriesService.updateCategory(category);
			if (isUpdated) {
				message = "Category updated successfully!";
				success = true;
			} else {
				message = "Failed to update category. Please try again.";
				success = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			message = "Error occurred while updating the category.";
			success = false;
		}

		mView.setViewName("customer/updateCategory");
		mView.addObject("message", message);
		mView.addObject("success", success);
		return mView;
	}

    
   
    

    
}