package com.cartify.product.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cartify.product.entities.Product;
import com.cartify.product.services.ProductService;

@Controller
@RequestMapping("/product")
public class ProductController {

	Product product;

	@Autowired
	ProductService productService;

	@GetMapping("/openProductIndexPage")
	public String openProductIndexPage() {
		System.out.println("\n Inside product index page");
		return "product/index";
	}

	@GetMapping("/openAddProductPage")
	public String openAddProductPage() {
		System.out.println("\n Inside add Product page");
		return "product/AddProduct";
	}

	@GetMapping("/openViewProductPage")
	public String openViewProductPage(Model model) {

		List<Product> products = productService.getAllProducts();

		model.addAttribute("products", products);

		System.out.println("\n Inside view Product page");

		return "product/viewProducts";
	}
	
	@GetMapping("/openDeleteProductPage")
	public String openDeleteProductPage(Model model) {

		List<Product> products = productService.getAllProducts();

		model.addAttribute("products", products);

		System.out.println("\n Inside delete Product page");

		return "product/deleteProduct";
	}

	@GetMapping("/openUpdateProductPage")
	public String openUpdateProductPage(Model model) {
		
		List<Product> products = productService.getAllProducts();

		model.addAttribute("products", products);
		System.out.println("\n Inside update Product page");
		return "product/updateProduct";
	}
	
	@PostMapping("/updateProduct")
	public ModelAndView updateProduct(@ModelAttribute Product product, ModelAndView mView) {
		
		String message;
		boolean success;
		
		System.out.println("Updating Product: " + product);
		
		try {
			boolean isUpdated = productService.updateProduct(product);
			if(isUpdated) {
				message = "Product Updated Successfully";
				success = true;
			} else {
				message = " Failed to update the Product. Please update the product Once again";
				success = true;
			}
		}catch (Exception e) {
			e.printStackTrace();
			message = "Error occurred while updating the product.";
			success = false;
		}
		List<Product> products = productService.getAllProducts();
	    mView.addObject("products", products);
	    mView.addObject("message", message);
	    mView.addObject("success", success);
	    mView.setViewName("product/updateProduct"); // Set the view name directly
	    return mView;
	}

	@PostMapping("/addProduct")
	public ModelAndView addProduct(@ModelAttribute Product product, ModelAndView mView) {

		System.out.println("Inside AddProduct page --------------");
		System.out.println(product);

		mView.setViewName("product/AddProduct");

		int result = 0;
		String message = "";
		try {
			result = productService.addProduct(product);
			if (result <= 0) {
				message = "Added failed. \n Please try again.";
			} else {
				message = "Added Successful. \n Please  continue.";
			}
		} catch (IOException | SQLException e) {
			e.printStackTrace();
		}
		mView.addObject("message", message);

		return mView;
	}

	@GetMapping("/openElectronicsPage")
	public String openElectronicsPage(Model model) {

		List<Product> productsList = productService.getAllProducts(1);

		model.addAttribute("productsList", productsList);

		System.out.println("\n Inside the Elctronics page");

		return "product/electronics1";

	}

	@GetMapping("/openAccessoriesPage")
	public String openAccessoriesPage(Model model) {

		List<Product> productsList = productService.getAllProducts(2);

		model.addAttribute("productsList", productsList);

		System.out.println("\n Inside the Accessories page");

		return "product/accessories";

	}

	@GetMapping("/openClothingPage")
	public String openClothingPage(Model model) {

		List<Product> productsList = productService.getAllProducts(3);

		model.addAttribute("productsList", productsList);

		System.out.println("\n Inside the clothing page");

		return "product/clothing";

	}
	


	
	@PostMapping("/deleteProduct")
	public ModelAndView deleteProduct(@RequestParam("productId") int productId, ModelAndView mView) {

	    System.out.println("Inside deleteProduct page --------------");

	    int result = productService.deleteProduct(productId);
	    String message = (result <= 0) ? "Delete failed. Please try again." : "Delete successful. Please continue.";
	    System.out.println("\n The deleted product Id is:" + productId);

	    // Fetch the updated list of products after deletion
	    List<Product> products = productService.getAllProducts();

	    mView.addObject("products", products);
	    mView.addObject("message", message);
	    mView.setViewName("product/deleteProduct");

	    return mView;
	}

}
