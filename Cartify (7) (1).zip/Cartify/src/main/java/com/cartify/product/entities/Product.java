package com.cartify.product.entities;

import org.springframework.web.multipart.MultipartFile;

public class Product {
	
	private int productId;
	private String productName;
	private String productPrice;
	private String productDescription;
	private int quantity;
	private MultipartFile productImage;
	private int categoryId;
	
	public Product() {
		super();
	}

	public Product(int productId, String productName, String productPrice, String productDescription, int quantity,
			MultipartFile productImage, int categoryId) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productPrice = productPrice;
		this.productDescription = productDescription;
		this.quantity = quantity;
		this.productImage = productImage;
		this.categoryId = categoryId;
	}

	public Product(String productName, String productPrice, String productDescription, int quantity,
			MultipartFile productImage, int categoryId) {
		super();
		this.productName = productName;
		this.productPrice = productPrice;
		this.productDescription = productDescription;
		this.quantity = quantity;
		this.productImage = productImage;
		this.categoryId = categoryId;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(String productPrice) {
		this.productPrice = productPrice;
	}

	public String getProductDescription() {
		return productDescription;
	}

	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public MultipartFile getProductImage() {
		return productImage;
	}

	public void setProductImage(MultipartFile productImage) {
		this.productImage = productImage;
	}

	public int getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}

	@Override
	public String toString() {
		return "\n Product [productId=" + productId + ", productName=" + productName + ", productPrice=" + productPrice
				+ ", productDescription=" + productDescription + ", quantity=" + quantity + ", productImage="
				+ productImage + ", categoryId=" + categoryId + "]";
	}
}
