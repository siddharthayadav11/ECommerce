package com.cartify.product.repository;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.cartify.product.entities.Categories;


public interface CategoriesDao {

	List<Categories> getAllCategories();
	
	List<Categories> getAllCategories(String categoryName);

	int addCategories(Categories categories)throws SQLException,IOException;
	
	 Categories findCategoryByName(String categoryName);
	    
	    boolean updateCategory(Categories category);
	 
	
}
