package com.cartify.product.repository;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.cartify.product.entities.Categories;

@Repository
public class CategoriesDaoImpl implements CategoriesDao {
    
    @Autowired
    JdbcTemplate jdbcTemplate;
    
    public JdbcTemplate getJdbcTemplate() {
        return jdbcTemplate;
    }
    
    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
    	this.jdbcTemplate = jdbcTemplate;
    }
    
    @Override
    public List<Categories> getAllCategories() {
    	
        final String GET_ALL_CATEGORIES = "SELECT * FROM category";
        
        return jdbcTemplate.query(GET_ALL_CATEGORIES, new CategoriesRowMapper());
    }

    @Override
    public List<Categories> getAllCategories(String categoryName) {
        final String GET_ALL_CATEGORIES_BY_CATEGORY = "SELECT * FROM category WHERE category_name = ?";
        return jdbcTemplate.query(GET_ALL_CATEGORIES_BY_CATEGORY, new CategoriesRowMapper(), categoryName);
    }

    @Override
	public int addCategories(Categories categories) throws SQLException , IOException{
		final String INSERT_QUERY = "INSERT INTO category(category_id,category_name,description) VALUES(?,?,?)";
		return jdbcTemplate.update(INSERT_QUERY,categories.getCategoryId(),categories.getCategoryName(),categories.getDescription());
	}

    
    
    @Override
    public Categories findCategoryByName(String categoryName) {
        final String SELECT_QUERY = "SELECT * FROM category WHERE category_name = ?";
        return jdbcTemplate.queryForObject(SELECT_QUERY, new Object[]{categoryName}, (rs, rowNum) -> {
        	Categories category = new Categories();
            category.setCategoryName(rs.getString("category_name"));
            category.setDescription(rs.getString("description"));
            return category;
        });
    }
    
    @Override
    public boolean updateCategory(Categories category) {
        final String UPDATE_QUERY = "UPDATE category SET description = ? WHERE category_name = ?";
        return jdbcTemplate.update(UPDATE_QUERY, category.getDescription(), category.getCategoryName()) > 0;
    }
    
   
	

}




