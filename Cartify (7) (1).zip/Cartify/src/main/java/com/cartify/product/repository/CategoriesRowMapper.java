package com.cartify.product.repository;

import java.sql.ResultSet;

import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.cartify.product.entities.Categories;



public class CategoriesRowMapper implements RowMapper<Categories> {
	
    @Override
    public Categories mapRow(ResultSet rs, int rowNum) throws SQLException {
    	
        int categoryId = rs.getInt("category_id");
        String categoryName = rs.getString("category_name");
        String description = rs.getString("description");

        return new Categories(categoryId, categoryName, description);
    }
}