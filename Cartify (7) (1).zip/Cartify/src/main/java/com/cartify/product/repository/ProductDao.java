package com.cartify.product.repository;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.sql.rowset.serial.SerialException;

import org.springframework.dao.DataAccessException;

import com.cartify.product.entities.Product;



public interface ProductDao {
	
	int insertProduct(Product product) throws SerialException, IOException, SQLException;
	List<Product> getAllProducts(int categoryId);
	boolean updateProduct(Product product) throws DataAccessException, SerialException, IOException, SQLException;
	
	List<Product> getAllProducts();
	
	int deleteProduct(int productId);
}
