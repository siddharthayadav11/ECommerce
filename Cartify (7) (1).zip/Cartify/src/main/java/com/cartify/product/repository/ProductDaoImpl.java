package com.cartify.product.repository;

import java.io.IOException;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.List;

import javax.sql.rowset.serial.SerialBlob;
import javax.sql.rowset.serial.SerialException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.web.multipart.MultipartFile;

import com.cartify.product.entities.Product;



@Repository
public class ProductDaoImpl implements ProductDao{
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public int insertProduct(Product product) throws SerialException, IOException, SQLException {
		
		MultipartFile image = product.getProductImage();
		
		Blob productImage = convertToBlob(image);
		
		final String ADD_PRODUCT_QUERY = "insert into product"
				+ "(product_name,product_price,product_description,quantity,product_image,category_id) "
				+ "values(?,?,?,?,?,?)";
		return jdbcTemplate.update(ADD_PRODUCT_QUERY, product.getProductName(),product.getProductPrice(),product.getProductDescription(),product.getQuantity(),productImage,product.getCategoryId());
	}
	
	private Blob convertToBlob(MultipartFile image) throws IOException, SerialException, SQLException {
		byte[] imageBytes = image.getBytes();
	
	Blob imageblob = new SerialBlob(imageBytes);
	
	return imageblob;
	}

	@Override
	public List<Product> getAllProducts(int categoryId) {
		
		final String GET_ALL_PRODUCTS = "SELECT * FROM product where category_id = ?";
		return jdbcTemplate.query(GET_ALL_PRODUCTS, new ProductRowMapper(), categoryId);
	}

	@Override
	public boolean updateProduct(Product product) throws DataAccessException, SerialException, IOException, SQLException {
		final String UPDATE_PRODUCT = "UPDATE product SET product_name = ?, product_price = ?, product_description = ?, quantity = ?, product_image = ? WHERE product_id = ?";
		return jdbcTemplate.update(UPDATE_PRODUCT, product.getProductName(), product.getProductPrice(), product.getProductDescription(), product.getQuantity(), convertToBlob(product.getProductImage()), product.getProductId()) > 0;
	}

	@Override
	public List<Product> getAllProducts() {
		final String VIEW_PRODUCTS = "SELECT * FROM product";
		return jdbcTemplate.query(VIEW_PRODUCTS, new ProductRowMapper());
	}

	@Override
	public int deleteProduct(int productId) {
		final String DELETE_PRODUCT = "DELETE FROM product WHERE product_id = ?";
		
		return jdbcTemplate.update(DELETE_PRODUCT, productId);
	}

}
