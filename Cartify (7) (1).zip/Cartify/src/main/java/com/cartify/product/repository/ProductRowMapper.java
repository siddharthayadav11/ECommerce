package com.cartify.product.repository;

import java.sql.Blob;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.web.multipart.MultipartFile;

import com.cartify.product.entities.Product;
import com.cartify.utils.ByteArrayMultipartFile;


public class ProductRowMapper implements RowMapper<Product>{

	@Override
	public Product mapRow(ResultSet rs, int rowNum) throws SQLException {
		int productId = rs.getInt("product_id");
		String productName = rs.getString("product_name");
		String productPrice = rs.getString("product_price");
		String productDescription = rs.getString("product_description");
		int quantity = rs.getInt("quantity");
		
		Blob image = rs.getBlob("product_image");
		
		byte[] imageBytes = image.getBytes(1, (int)image.length());
		MultipartFile productImage = new ByteArrayMultipartFile(imageBytes,"image.jpg", "image/jpg");
		
		
		int categoryId = rs.getInt("category_id");
		
		
		
		return new Product(productId, productName, productPrice, productDescription, quantity, productImage, categoryId);
	}

}
