package com.cartify.product.services;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.cartify.product.entities.Categories;



public interface CategoriesService {

	List<Categories> fetchAllCategories();
	
	List<Categories> fetchAllCategories(String categoryName);

	int addCategories(Categories categories)throws SQLException, IOException;
	
	Categories findCategoryByName(String categoryName);

	boolean updateCategory(Categories category);

	boolean isCategoryExists(String categoryName);
	 
	
}
