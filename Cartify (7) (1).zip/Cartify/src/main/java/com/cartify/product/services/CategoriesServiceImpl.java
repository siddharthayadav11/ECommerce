package com.cartify.product.services;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cartify.product.entities.Categories;
import com.cartify.product.repository.CategoriesDao;

@Service
public class CategoriesServiceImpl implements CategoriesService{

	@Autowired
	CategoriesDao categoriesDao;
	
	@Override
	public List<Categories> fetchAllCategories() {
		
		return categoriesDao.getAllCategories();
	}

	@Override
	public List<Categories> fetchAllCategories(String categoryName) {
		
		return categoriesDao.getAllCategories(categoryName);
	}

	@Override
	public int addCategories(Categories categories) throws SQLException, IOException {
		
		return categoriesDao.addCategories(categories);
	}

	
	@Override
	public Categories findCategoryByName(String categoryName) {
	    return categoriesDao.findCategoryByName(categoryName);
	}
	 
	@Override
	public boolean updateCategory(Categories category) {
	    return categoriesDao.updateCategory(category);
	}
	
	@Override
    public boolean isCategoryExists(String categoryName) {
        return categoriesDao.getAllCategories(categoryName).size() > 0;
    }
	

}
