package com.cartify.product.services;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.sql.rowset.serial.SerialException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import com.cartify.product.entities.Product;
import com.cartify.product.repository.ProductDao;


@Service
public class ProductServiceImpl implements ProductService{
	
	@Autowired
	ProductDao productDao;

	@Override
	public int addProduct(Product product) throws SerialException, IOException, SQLException {
		return productDao.insertProduct(product);
		}

	@Override
	public List<Product> getAllProducts(int categoryId) {
		return productDao.getAllProducts(categoryId);
		}

	@Override
	public boolean updateProduct(Product product) throws DataAccessException, SerialException, IOException, SQLException {
		return productDao.updateProduct(product);
		}

	@Override
	public List<Product> getAllProducts() {
		return productDao.getAllProducts();
	}

	@Override
	public int deleteProduct(int productId) {
		return productDao.deleteProduct(productId);
	}

}
