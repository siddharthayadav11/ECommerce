package com.cartify.user.controller;

import com.cartify.user.entities.Admin;
import com.cartify.user.entities.Customer;
import com.cartify.user.entities.CustomerProjection;
import com.cartify.user.entities.SubAdmin;
import com.cartify.user.entities.SubadminProjection;
import com.cartify.user.services.AdminService;
import com.cartify.user.services.CustomerService;
import com.cartify.user.services.SubAdminService;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/customer")
public class AdminController {

	
	 
	@Autowired
	private CustomerService customerService;
    @Autowired
    private SubAdminService subAdminService;

    @Autowired
    private AdminService adminService;

    // Open the login page
   

    // Open the SubAdmin creation form
    @GetMapping("/openSubAdminForm")
    public String openSubAdminForm(HttpSession session) {
    	Customer customer = (Customer) session.getAttribute("customer");
		Admin loggedInAdmin = (Admin) session.getAttribute("loggedInAdmin");
		SubAdmin loggedInSubAdmin = (SubAdmin) session.getAttribute("loggedInSubAdmin");

		// If neither customer, loggedInAdmin, nor loggedInSubAdmin is present, redirect
		// to login
		if (customer == null && loggedInAdmin == null && loggedInSubAdmin == null) {
			return "redirect:/customer/login";
		}

		// Assuming roleId check is only for customers
		if (customer != null) {
			int roleId = customer.getRole();
			if (roleId != 1 && roleId != 2) {
				return "notAuthorized";
			}
		}

        return "customer/subAdminForm";  // Refers to the SubAdmin creation forma
    }
    
    @GetMapping("/openManageProduct")
    public String openManageProduct(HttpSession session) {
    	Customer customer = (Customer) session.getAttribute("customer");
		Admin loggedInAdmin = (Admin) session.getAttribute("loggedInAdmin");
		SubAdmin loggedInSubAdmin = (SubAdmin) session.getAttribute("loggedInSubAdmin");

		// If neither customer, loggedInAdmin, nor loggedInSubAdmin is present, redirect
		// to login
		if (customer == null && loggedInAdmin == null && loggedInSubAdmin == null) {
			return "redirect:/customer/login";
		}

		// Assuming roleId check is only for customers
		if (customer != null) {
			int roleId = customer.getRole();
			if (roleId != 1 && roleId != 2) {
				return "notAuthorized";
			}
		}
        return "customer/manageProduct"; // Path to the JSP file relative to the configured view prefix
    }

    
    @GetMapping("/openAdmin")
    public String openAdmin(HttpSession session) {
    	Customer customer = (Customer) session.getAttribute("customer");
		Admin loggedInAdmin = (Admin) session.getAttribute("loggedInAdmin");
		SubAdmin loggedInSubAdmin = (SubAdmin) session.getAttribute("loggedInSubAdmin");

		// If neither customer, loggedInAdmin, nor loggedInSubAdmin is present, redirect
		// to login
		if (customer == null && loggedInAdmin == null && loggedInSubAdmin == null) {
			return "redirect:/customer/login";
		}

		// Assuming roleId check is only for customers
		if (customer != null) {
			int roleId = customer.getRole();
			if (roleId != 1 && roleId != 2) {
				return "notAuthorized";
			}
		}
       return "customer/admin";
    }
    
    @GetMapping("/manageUser")
    public String manageUser(HttpSession session) {
    	Customer customer = (Customer) session.getAttribute("customer");
		Admin loggedInAdmin = (Admin) session.getAttribute("loggedInAdmin");
		SubAdmin loggedInSubAdmin = (SubAdmin) session.getAttribute("loggedInSubAdmin");

		// If neither customer, loggedInAdmin, nor loggedInSubAdmin is present, redirect
		// to login
		if (customer == null && loggedInAdmin == null && loggedInSubAdmin == null) {
			return "redirect:/customer/login";
		}

		// Assuming roleId check is only for customers
		if (customer != null) {
			int roleId = customer.getRole();
			if (roleId != 1 && roleId != 2) {
				return "notAuthorized";
			}
		}
    	return "customer/manageUser";
    }
    
    @GetMapping("/openInventoryPage")
    public ModelAndView openInventoryPage(ModelAndView modelAndView) {
    	int productCount = customerService.productCount();
    	int categoryCount = customerService.categoryCount();
    	int orderCount = customerService.orderCount();
    	
    	Map<String, Integer> map = new HashMap<>();
    	map.put("productCount", productCount);
    	map.put("categoryCount", categoryCount);
    	map.put("orderCount", orderCount);
    	modelAndView.addObject("data", map);

    	modelAndView.setViewName("customer/inventory");
    	return modelAndView;
    }

   
    @GetMapping("/admin")
    public String adminPage(HttpSession session) {
      
        Admin loggedInAdmin = (Admin) session.getAttribute("loggedInAdmin");
        if (loggedInAdmin == null) {
            return "redirect:/customer/login";  
        }
        return "customer/admin";  
    }


    // Create a new SubAdmin
    @PostMapping("/createSubAdmin")
    public String createSubAdmin(
    		
        @RequestParam("name") String name,
        @RequestParam("email") String email,
        @RequestParam("password") String password,
        RedirectAttributes redirectAttributes
    ) {
    	
    	
        try {
        	
        	
            // Create new SubAdmin entity and save it
            SubAdmin subAdmin = new SubAdmin();
            subAdmin.setFullName(name);
            subAdmin.setEmail(email);
            subAdmin.setPassword(password);

            subAdminService.createSubAdmin(subAdmin);
            redirectAttributes.addFlashAttribute("message", "Sub-Admin created successfully.");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error while creating Sub-Admin: " + e.getMessage());
        }
        return "redirect:/customer/openSubAdminForm";
    }
    
   

    
  

        @GetMapping("/editSuperAdmin")
        public String editSuperAdmin(HttpSession session, Model model) {
            // Fetch super admin details (in this case, hardcoded or from DB)
            Admin superAdmin = adminService.getSuperAdminDetails(); // This method fetches the admin details
            model.addAttribute("superAdmin", superAdmin);
            return "customer/editAdmin";  // JSP page for editing
        }

        @PostMapping("/updateSuperAdminDetails")
        public String updateSuperAdminDetails(
            @RequestParam("name") String name,
            @RequestParam("email") String email,
            @RequestParam("mobile") String mobile,
            HttpSession session,
            RedirectAttributes redirectAttributes) {
            
            // Fetch the current Super Admin details from session or DB
            Admin superAdmin = adminService.getSuperAdminDetails(); // Retrieve the admin object
            
            if (superAdmin != null) {
                // Update the admin's details
                superAdmin.setFullName(name);
                superAdmin.setEmail(email);
                superAdmin.setMobile(mobile);

                // Save the updated details to the database
                try {
                    adminService.updateAdminDetails(superAdmin); // Save the updated details
                    redirectAttributes.addFlashAttribute("message", "Details updated successfully.");
                } catch (Exception e) {
                    redirectAttributes.addFlashAttribute("error", "Error updating details: " + e.getMessage());
                }
            } else {
                redirectAttributes.addFlashAttribute("error", "Admin not found.");
                return "redirect:/customer/login"; // Redirect to login if admin not found
            }

            return "redirect:/customer/editSuperAdmin"; // Redirect back to edit page
        }
        
        @GetMapping("/openManageSubadmins")
        public String openManageSubadmins(Model model) {
            List<SubadminProjection> subadmins = subAdminService.getAllSubadmins();
            model.addAttribute("subadmins", subadmins);
            return "customer/manageSubadmins"; // The JSP page to display subadmins
        }
        
        @GetMapping("/openManageCustomers")
        public String openManageCustomers(Model model) {
            List<CustomerProjection> customers = customerService.getAllCustomers();
            model.addAttribute("customers", customers);
            return "customer/manageCustomers";
        }
        
        @PostMapping("/toggleAuthorization")
        public String toggleAuthorization(@RequestParam("email") String email, RedirectAttributes redirectAttributes) {
            subAdminService.toggleAuthorization(email);  // Perform the status update operation

            // Add the success flag to the redirect attributes
            redirectAttributes.addAttribute("statusUpdated", "true");

            // Redirect back to the same page
            return "redirect:/customer/openManageSubadmins";  // Keep the same URL
        }


        

      

     



        }




