package com.cartify.user.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.cartify.user.entities.Admin;
import com.cartify.user.entities.Customer;
import com.cartify.user.entities.SubAdmin;
import com.cartify.user.services.CustomerService;

import com.cartify.user.services.SubAdminService;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/customer")
public class CustomerController {

	
	Customer customer;
	@Autowired
	CustomerService customerService;

	@Autowired
	SubAdminService subAdminService;
	
	 

	// Login Page
	@GetMapping("/login")
	public String openLoginPage() {
		return "customer/login"; // Serve the login page
	}
	
	@GetMapping("/profile")
	public String profile() {
		return "customer/profile";
	}

	// Registration Page
	@GetMapping("/openRegistrationPage")
	public String openRegistrationPage() {
		return "customer/registration"; // Serve the registration page
	}

	// Forgot Password Page
	@GetMapping("/openForgotpasswordPage")
	public String openForgotPasswordPage() {
		return "resetPassword"; // Serve the forgot password page
	}

	@PostMapping("/login")
	public ModelAndView login(@RequestParam String email, @RequestParam String password, ModelAndView mView,
			HttpSession session) {

		// Step 1: Try fetching the customer (which could be a Super Admin, Sub Admin,
		// or Customer)
		Optional<Customer> optCustomer = customerService.fetchCustomerDetails(email);

		// Step 2: If customer is found, check the password
		if (optCustomer.isPresent()) {
			Customer customer = optCustomer.get();
			
			// Check if the password is correct for Customer
			boolean passwordMatches = customerService.matchPassword(password, customer);
			System.out.println("Password Matches: " + passwordMatches); // Check if it's true or false
			if (!passwordMatches) {
				mView.setViewName("customer/login");
				mView.addObject("message", "Incorrect password.");
				return mView;
			}

			// Check if the user is authorized (assuming authorized is 1 for authorized, 0
			// for not authorized)
			if (!customer.isAuthorized()) { // This checks if authorized is 0
				mView.setViewName("customer/login");
				mView.addObject("message", "Your account is not authorized. Please contact the admin.");
				return mView;
			}

			// Role-based redirection for Customer
			switch (customer.getRole()) {
			case 1: // Super Admin
				Admin loggedInAdmin = new Admin(customer);
				session.setAttribute("loggedInAdmin", loggedInAdmin);
				return new ModelAndView("redirect:/customer/admin"); // Redirect to admin page
			case 2: // Sub Admin
				SubAdmin loggedInSubAdmin = new SubAdmin(customer);
				session.setAttribute("loggedInSubAdmin", loggedInSubAdmin);
				return new ModelAndView("redirect:/customer/subAdmin");

			case 3: // Customer
				session.setAttribute("customer", customer);
				session.setAttribute("email", customer.getEmail());
				return new ModelAndView("redirect:/"); // Redirect to homepage

			default:
				mView.setViewName("customer/login");
				mView.addObject("message", "Role not recognized.");
				return mView;
			}
		}

		// If the customer is not found
		session.setAttribute("email", customer.getEmail());
		//mView.setViewName("customer/login");
		mView.addObject("message", "Invalid email address.");
		return mView;
	}

	// Logout logic
	@GetMapping("/logout")
	public String logout(HttpSession session, RedirectAttributes redirectAttributes) {
		session.invalidate(); // Invalidate the session
		redirectAttributes.addFlashAttribute("message", "You have logged out successfully.");
		return "redirect:/customer/login"; // Redirect to login page
	}

	// Handle Customer Registration
	@PostMapping("/registration")
	public String customerRegistration(@ModelAttribute Customer customer, RedirectAttributes redirectAttributes) {

		int result = customerService.registerCustomer(customer);
		String message = "Registration Successful. Please login to continue.";

		if (result <= 0) {
			message = "Registration failed. Please try again.";
		}

		redirectAttributes.addFlashAttribute("message", message);
		return "redirect:/customer/login"; // Redirect to login after successful registration
	}

	}

