package com.cartify.user.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.cartify.user.entities.Admin;
import com.cartify.user.entities.Customer;
import com.cartify.user.entities.SubAdmin;
import com.cartify.user.services.SubAdminService;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/customer")
public class SubAdminController {
	
	
	@Autowired
    private SubAdminService subAdminService;

	    // Show the SubAdmin page
	    @GetMapping("/subAdmin")
	    public String subAdminPage(HttpSession session) {
	        // Check if the sub-admin is logged in
	        SubAdmin loggedInAdmin = (SubAdmin) session.getAttribute("loggedInSubAdmin");
	        if (loggedInAdmin == null) {
	            return "redirect:/customer/login";  // Redirect to login if not logged in
	        }
	        return "customer/subAdmin";  // Render subAdmin JSP if logged in
	    }
    
	    @GetMapping("/openManageProductSubAdmin")
	    public String openManageProduct(HttpSession session) {
	    	Customer customer = (Customer) session.getAttribute("customer");
			Admin loggedInAdmin = (Admin) session.getAttribute("loggedInAdmin");
			SubAdmin loggedInSubAdmin = (SubAdmin) session.getAttribute("loggedInSubAdmin");

			// If neither customer, loggedInAdmin, nor loggedInSubAdmin is present, redirect
			// to login
			if (customer == null && loggedInAdmin == null && loggedInSubAdmin == null) {
				return "redirect:/customer/login";
			}

			// Assuming roleId check is only for customers
			if (customer != null) {
				int roleId = customer.getRole();
				if (roleId != 1 && roleId != 2) {
					return "notAuthorized";
				}
			}
	        return "customer/manageProductSubAdmin"; // Path to the JSP file relative to the configured view prefix
	    }


        @GetMapping("/editSubAdmin")
        public String editSuperAdmin(HttpSession session, Model model) {
        	 SubAdmin subAdmin = subAdminService.getSubAdminDetails(); // This method fetches the admin details
             model.addAttribute("subAdmin", subAdmin);
            return "customer/editSubAdmin";  // JSP page for editing
        }
    
        
        @PostMapping("/updateSubAdminDetails")
        public String updateSubAdminDetails(
            @RequestParam("name") String name,
            @RequestParam("email") String email,
            @RequestParam("mobile") String mobile,
            HttpSession session,
            RedirectAttributes redirectAttributes) {
            
            // Fetch the current Super Admin details from session or DB
            SubAdmin subAdmin = subAdminService.getSubAdminDetails(); // Retrieve the admin object
            
            if (subAdmin != null) {
                // Update the admin's details
                subAdmin.setFullName(name);
                subAdmin.setEmail(email);
                subAdmin.setMobile(mobile);

                // Save the updated details to the database
                try {
                	subAdminService.updateSubAdminDetails(subAdmin); // Save the updated details
                    redirectAttributes.addFlashAttribute("message", "Details updated successfully.");
                } catch (Exception e) {
                    redirectAttributes.addFlashAttribute("error", "Error updating details: " + e.getMessage());
                }
            } else {
                redirectAttributes.addFlashAttribute("error", "Admin not found.");
                return "redirect:/customer/login"; // Redirect to login if admin not found
            }

            return "redirect:/customer/editSubAdmin"; // Redirect back to edit page
        }


}
