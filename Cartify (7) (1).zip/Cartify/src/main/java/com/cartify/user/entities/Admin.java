package com.cartify.user.entities;


import java.time.LocalDateTime;

public class Admin {
	private int id;
	private String fullName;
	private String email;
	private String mobile;
	private String password;
	private String confirmpassword;
	private String pwdSalt;
	private String pwdHash;
	private boolean authorized;
	private int roleId;
	
	public Admin() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Admin(Customer customer) {
		super();
		this.id = customer.getId();
		this.fullName = customer.getFullName();
		this.email = customer.getEmail();
		this.mobile = customer.getMobile();
		this.password = customer.getPassword();
		this.confirmpassword = customer.getConfirmpassword();
		this.pwdSalt = customer.getPwdSalt();
		this.pwdHash = customer.getPwdHash();
		this.authorized = customer.isAuthorized();
		this.roleId = 1;
		
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getConfirmpassword() {
		return confirmpassword;
	}
	public void setConfirmpassword(String confirmpassword) {
		this.confirmpassword = confirmpassword;
	}
	public String getPwdSalt() {
		return pwdSalt;
	}
	public void setPwdSalt(String pwdSalt) {
		this.pwdSalt = pwdSalt;
	}
	public String getPwdHash() {
		return pwdHash;
	}
	public void setPwdHash(String pwdHash) {
		this.pwdHash = pwdHash;
	}
	public boolean isAuthorized() {
		return authorized;
	}
	public void setAuthorized(boolean authorized) {
		this.authorized = authorized;
	}
	public int getRole() {
		return roleId;
	}
	public void setRoleId(int roleId) {
		this.roleId = roleId;
	}
	@Override
	public String toString() {
		return "Admin [id=" + id + ", fullName=" + fullName + ", email=" + email + ", mobile=" + mobile + ", password="
				+ password + ", confirmpassword=" + confirmpassword + ", pwdSalt=" + pwdSalt + ", pwdHash=" + pwdHash
				+ ", authorized=" + authorized + ", roleId=" + roleId + "]";
	}
	
	
	
        }
