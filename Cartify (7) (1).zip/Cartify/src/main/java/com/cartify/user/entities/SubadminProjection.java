package com.cartify.user.entities;

public class SubadminProjection {

    private String fullName;
    private String email;
    private int authorized;

    // Constructor
    public SubadminProjection(String fullName, String email, int authorized) {
        this.fullName = fullName;
        this.email = email;
        this.authorized = authorized;
    }

    // Getters and Setters
    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getAuthorized() {
        return authorized;
    }

    public void setAuthorized(int authorized) {
        this.authorized = authorized;
    }

    // A method to return the status based on the authorized field
    public String getAuthorizationStatus() {
        return authorized == 1 ? "Active" : "Revoked";
    }
}
