
package com.cartify.user.repository;

import java.time.LocalDateTime;

import com.cartify.user.entities.Admin;

public interface AdminDao {

	void updateAdminDetails(Admin superAdmin);

	Admin getSuperAdminDetails();
    
}



