package com.cartify.user.repository;




import com.cartify.user.entities.Admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;

@Repository
public class AdminDaoImpl implements AdminDao {
	
	
@Autowired
    private final JdbcTemplate jdbcTemplate;

    public AdminDaoImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    

   

	@Override
	public Admin getSuperAdminDetails() {
		String sql = "SELECT * FROM customer WHERE role_id = '1'"; // Assuming 'SUPER_ADMIN' role is hardcoded

        try {
            return jdbcTemplate.queryForObject(sql, new Object[]{}, new BeanPropertyRowMapper<>(Admin.class));
        } catch (EmptyResultDataAccessException e) {
            return null; // Handle the case where no admin is found
        }
        
      
    }
	
	  public void updateAdminDetails(Admin superAdmin) {
          String sql = "UPDATE customer SET full_name = ?, email = ?, mobile = ? WHERE role_id = '1'"; // Update based on role or ID
          
          jdbcTemplate.update(sql, superAdmin.getFullName(), superAdmin.getEmail(), superAdmin.getMobile());
      }
	}


	

  
    

