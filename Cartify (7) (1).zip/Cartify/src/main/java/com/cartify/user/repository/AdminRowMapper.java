package com.cartify.user.repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

import com.cartify.user.entities.Admin;

public class AdminRowMapper implements RowMapper<Admin> {

    @Override
    public Admin mapRow(ResultSet rs, int rowNum) throws SQLException {
        Admin admin = new Admin();
        
        admin.setId(rs.getInt("id"));
        admin.setFullName(rs.getString("name"));
        admin.setEmail(rs.getString("email"));
        admin.setMobile(rs.getString("mobile"));
        admin.setPwdSalt(rs.getString("pwd_salt"));
		admin.setPwdHash(rs.getString("pwd_hash"));
		boolean isAuthorized = rs.getBoolean("authorized");
		int role_id = rs.getInt("role_id");
       
        
        return admin;
    }
}
