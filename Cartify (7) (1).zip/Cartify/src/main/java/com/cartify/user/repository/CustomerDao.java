package com.cartify.user.repository;

import java.util.List;
import java.util.Optional;

import com.cartify.user.entities.Customer;
import com.cartify.user.entities.CustomerProjection;

public interface CustomerDao {
	
	int insertCustomer(Customer customer);
	
	Optional<Customer> getCustomerData(String email);
	
	int updatePassword(String newUpdatedSalt, String newUpdatedHash);

	 List<CustomerProjection>getAllCustomers();
	 
	 int productCount();
	 
	 int categoryCount();
	 
	 int orderCount();

	

}
