package com.cartify.user.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.cartify.user.entities.Customer;
import com.cartify.user.entities.CustomerProjection;


@Repository
public class CustomerDaoImpl implements CustomerDao{
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public int insertCustomer(Customer customer) {final String INSERT_QUERY = "INSERT INTO customer "
			+ "(full_name, email, mobile, pwd_salt, pwd_hash, authorized, role_id) "
			+ "VALUES (?,?,?,?,?,?,?)";
	
	return jdbcTemplate.update(INSERT_QUERY, customer.getFullName(), customer.getEmail(),customer.getMobile(),
		 customer.getPwdSalt(), customer.getPwdHash(), true, 3);}

	@Override
	public Optional<Customer> getCustomerData(String email) {
		
		Customer customer = null;
		
		final String GET_CUSTOMER = "SELECT * FROM customer WHERE email = ?";
		
		try {
			customer = jdbcTemplate.queryForObject(GET_CUSTOMER, new CustomerRowMapper(), email);
		} catch(DataAccessException dataAccessException) {
			dataAccessException.printStackTrace();
		}
		
		
		return Optional.ofNullable(customer);
	}

	@Override
	public int updatePassword(String newUpdatedSalt, String newUpdatedHash) {
		final String UPDATE_QUERY_PASSWORD = "update customer. set pwd_salt = ?, pwd_hash =? where email = ?";
		return jdbcTemplate.update(UPDATE_QUERY_PASSWORD);
	}

	@Override

	     public List<CustomerProjection> getAllCustomers() {
       
        String sql = "SELECT full_name, email FROM customer WHERE role_id = 3";

       
        return jdbcTemplate.query(sql, new CustomerProjectionRowMapper());

	}

	@Override
	public int productCount() {
		final String COUNT_PRODUCT = " SELECT COUNT(*) FROM product ";
		return jdbcTemplate.queryForObject(COUNT_PRODUCT, Integer.class);
	}

	@Override
	public int categoryCount() {
		final String COUNT_CATEGORY = " SELECT COUNT(*) FROM category ";
		return jdbcTemplate.queryForObject(COUNT_CATEGORY, Integer.class);
	}

	@Override
	public int orderCount() {
		final String COUNT_ORDER = " SELECT COUNT(*) FROM orders ";
		return jdbcTemplate.queryForObject(COUNT_ORDER, Integer.class);
	}
}


