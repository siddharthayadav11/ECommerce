package com.cartify.user.repository;



import com.cartify.user.entities.CustomerProjection;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class CustomerProjectionRowMapper implements RowMapper<CustomerProjection> {

    @Override
    public CustomerProjection mapRow(ResultSet rs, int rowNum) throws SQLException {
        // Map the result set to the CustomerProjection DTO
        String fullName = rs.getString("full_name");
        String email = rs.getString("email");

        // Return the CustomerProjection object
        return new CustomerProjection(fullName, email);
    }
}
