package com.cartify.user.repository;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.cartify.user.entities.Customer;




public class CustomerRowMapper implements RowMapper<Customer>{

	@Override
	public Customer mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		int id = rs.getInt("user_id");
		String fullName = rs.getString("full_name");
		String email = rs.getString("email");
		String phoneNumber = rs.getString("mobile");
		String pwdSalt = rs.getString("pwd_salt");
		String pwdHash = rs.getString("pwd_hash");
		boolean isAuthorized = rs.getBoolean("authorized");
		int role_id = rs.getInt("role_id");
		
		
		return new Customer(id, fullName, email, phoneNumber, pwdSalt, pwdHash, isAuthorized, role_id);
		
	}

}
