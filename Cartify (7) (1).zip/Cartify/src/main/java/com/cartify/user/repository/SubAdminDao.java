package com.cartify.user.repository;

import java.util.List;
import java.util.Optional;

import com.cartify.user.entities.Customer;
import com.cartify.user.entities.SubAdmin;
import com.cartify.user.entities.SubadminProjection;

public interface SubAdminDao {
	
	 boolean existsByEmail(String email);
	 int createSubAdmin(SubAdmin subAdmin) throws Exception;
	
	 List<SubadminProjection> getAllSubadmins();
	SubAdmin getSubAdminDetails();
	void updateSubAdminDetails(SubAdmin subAdmin);
	boolean updateAuthorizationStatus(String email, int newStatus);
	int getAuthorizationStatusByEmail(String email);
	SubadminProjection findByEmail(String email);
	
	
	
	
	
	
}

