package com.cartify.user.repository;


import java.util.List;
import java.util.Optional;

import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.cartify.user.entities.Admin;
import com.cartify.user.entities.Customer;
import com.cartify.user.entities.SubAdmin;
import com.cartify.user.entities.SubadminProjection;

@Repository
public class SubAdminDaoImpl implements SubAdminDao {

    private final JdbcTemplate jdbcTemplate;

    public SubAdminDaoImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public boolean existsByEmail(String email) {
        String sql = "SELECT COUNT(*) FROM customer WHERE email = ?";
        Integer count = jdbcTemplate.queryForObject(sql, Integer.class, email);
        return count != null && count > 0;
    }

    @Override
    public int createSubAdmin(SubAdmin subAdmin) {final String INSERT_QUERY = "INSERT INTO customer "
			+ "(full_name, email, mobile, pwd_salt, pwd_hash, authorized, role_id) "
			+ "VALUES (?,?,?,?,?,?,?)";
    	
    	
    	return jdbcTemplate.update(INSERT_QUERY, subAdmin.getFullName(), subAdmin.getEmail(),subAdmin.getMobile(),
    			 subAdmin.getPwdSalt(), subAdmin.getPwdHash(), true, 2);}

   
    
    public List<SubadminProjection> getAllSubadmins() {
        String sql = "SELECT full_name, email, authorized FROM customer WHERE role_id = 2"; 
        return jdbcTemplate.query(sql, new SubadminProjectionRowMapper());
    }
    
    
   
    @Override
	public SubAdmin getSubAdminDetails() {
		String sql = "SELECT * FROM customer WHERE role_id = '2'"; // Assuming 'SUPER_ADMIN' role is hardcoded

        try {
            return jdbcTemplate.queryForObject(sql, new Object[]{}, new BeanPropertyRowMapper<>(SubAdmin.class));
        } catch (EmptyResultDataAccessException e) {
            return null; // Handle the case where no admin is found
        }
	

  

    }

	@Override
	public void updateSubAdminDetails(SubAdmin subAdmin) {
		String sql = "UPDATE customer SET full_name = ?, email = ?, mobile = ? WHERE role_id = '2'"; // Update based on role or ID
        
        jdbcTemplate.update(sql, subAdmin.getFullName(), subAdmin.getEmail(), subAdmin.getMobile());
		
	}
	
	


	    // Fetch the current authorization status of a subadmin by email
	    public int getAuthorizationStatusByEmail(String email) {
	        String query = "SELECT authorized FROM customer WHERE email = ?";
	        try {
	            return jdbcTemplate.queryForObject(query, new Object[]{email}, Integer.class);
	        } catch (EmptyResultDataAccessException e) {
	            return -1; // Return -1 if no subadmin found for this email
	        } catch (Exception e) {
	            e.printStackTrace();
	            return -1; // Return -1 in case of any error
	        }
	    }

	    // Find a subadmin by email
	    public SubadminProjection findByEmail(String email) {
	        String query = "SELECT full_name, email, authorized FROM customer WHERE email = ?";
	        try {
	            System.out.println("Executing query for email: " + email); // Add a log to check the email being passed
	            return jdbcTemplate.queryForObject(query, new Object[]{email}, new SubadminProjectionRowMapper());
	        } catch (EmptyResultDataAccessException e) {
	            System.out.println("Subadmin not found for email: " + email); // Log the error
	            return null; // Return null if no subadmin is found
	        } catch (Exception e) {
	            e.printStackTrace();
	            return null; // Return null in case of any error
	        }
	    }


	    // Update the authorization status of a subadmin
	    public boolean updateAuthorizationStatus(String email, int newStatus) {
	        String query = "UPDATE customer SET authorized = ? WHERE email = ?";
	        try {
	            int rowsAffected = jdbcTemplate.update(query, newStatus, email);
	            return rowsAffected > 0; // Return true if at least one row is updated
	        } catch (Exception e) {
	            e.printStackTrace();
	            return false; // Return false if there's an error during the update
	        }
	    }
	}

	


	
	 

    
