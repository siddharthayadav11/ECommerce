package com.cartify.user.repository;

import com.cartify.user.entities.SubAdmin;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class SubAdminRowMapper implements RowMapper<SubAdmin> {

    @Override
    public SubAdmin mapRow(ResultSet rs, int rowNum) throws SQLException {
        // Create an instance of SubAdmin
        SubAdmin subAdmin = new SubAdmin();
        
        // Map each column in the ResultSet to the respective field in SubAdmin
        subAdmin.setId(rs.getInt("id"));
        subAdmin.setFullName(rs.getString("full_name"));
        subAdmin.setEmail(rs.getString("email"));
        subAdmin.setMobile(rs.getString("mobile"));
        subAdmin.setPassword(rs.getString("password"));
        subAdmin.setConfirmpassword(rs.getString("confirmpassword"));
        subAdmin.setPwdSalt(rs.getString("pwd_salt"));
        subAdmin.setPwdHash(rs.getString("pwd_hash"));
        subAdmin.setAuthorized(rs.getBoolean("authorized"));
        subAdmin.setRoleId(rs.getInt("role_id"));
        
        return subAdmin;
    }
}
