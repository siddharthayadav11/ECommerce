package com.cartify.user.repository;

import com.cartify.user.entities.SubadminProjection;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class SubadminProjectionRowMapper implements RowMapper<SubadminProjection> {

   
    @Override
    public SubadminProjection mapRow(ResultSet rs, int rowNum) throws SQLException {
        String fullName = rs.getString("full_name");
        String email = rs.getString("email");
        int authorized = rs.getInt("authorized");

        return new SubadminProjection(fullName, email, authorized);
    }

}
