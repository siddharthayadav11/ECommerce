package com.cartify.user.services;

import com.cartify.user.entities.Admin;

public interface AdminService {

	void updateAdminDetails(Admin superAdmin);

	Admin getSuperAdminDetails();
}

