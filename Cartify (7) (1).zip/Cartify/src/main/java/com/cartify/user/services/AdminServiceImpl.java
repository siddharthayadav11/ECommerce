package com.cartify.user.services;



import com.cartify.user.entities.Admin;
import com.cartify.user.repository.AdminDao;
import com.cartify.user.services.AdminService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Random;

@Service
public class AdminServiceImpl implements AdminService {

	
	@Autowired
    private AdminDao adminDao;

	@Override
	public void updateAdminDetails(Admin superAdmin) {
		  adminDao.updateAdminDetails(superAdmin);
		
	}

	@Override
	public Admin getSuperAdminDetails() {
		   return adminDao.getSuperAdminDetails();
	}

   
    
}
   

   