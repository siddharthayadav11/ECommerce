package com.cartify.user.services;

import java.util.List;
import java.util.Optional;

import com.cartify.user.entities.Customer;
import com.cartify.user.entities.CustomerProjection;



public interface CustomerService {
	
	int registerCustomer(Customer customer);
	
	
	Optional<Customer> fetchCustomerDetails(String email);
	

	boolean matchPassword(String password, Customer customer);
	
	int updatePassword(String password);


	List<CustomerProjection> getAllCustomers();
	
	int productCount();
	 
	 int categoryCount();
	 
	 int orderCount();

}
