package com.cartify.user.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cartify.user.entities.Customer;
import com.cartify.user.entities.CustomerProjection;
import com.cartify.user.repository.CustomerDao;
import com.cartify.utils.Utils;


@Service
public class CustomerServiceImp implements CustomerService{
	
	@Autowired
	CustomerDao customerDao;

	@Override
	public int registerCustomer(Customer customer) {

		System.out.println("\n Customer Data: " + customer);

		String pwdSalt = Utils.generateSalt();
		String originalPassword = customer.getPassword();
		
		String modifiedPassword = originalPassword + pwdSalt;

		String pwdHash = Utils.generatePwdHash(modifiedPassword);
		
		
		customer.setPwdSalt(pwdSalt);
		customer.setPwdHash(pwdHash);
		
		
		int role = customer.getId();
		
		 if(role == 3) {
			 customer.setAuthorized(true);
		 } 	 else if(role == 2) {
			 customer.setAuthorized(false);
		 }		
		

		return customerDao.insertCustomer(customer);
	}

	@Override
	public Optional<Customer> fetchCustomerDetails(String email) {
		
		return customerDao.getCustomerData(email);
	}

	@Override
	public boolean matchPassword(String passwordFromUi, Customer customer) {
		
		String pwdSaltFromDb = customer.getPwdSalt();
		
		String pwdHashFromDb = customer.getPwdHash();
	
		
		String modifiedPassword = passwordFromUi + pwdSaltFromDb;
		

		String newHash = Utils.generatePwdHash(modifiedPassword);
		
		
		return newHash.equals(pwdHashFromDb);
	}

	@Override
	public int updatePassword(String password) {
		
		String newUpdatedPasswordSalt = Utils.generateSalt();
		String newPassword = password;
		String newModifiedPassword = password + newUpdatedPasswordSalt;
		String newHashedPassword = Utils.generatePwdHash(newModifiedPassword);
		
		customerDao.getCustomerData(newUpdatedPasswordSalt);
		customerDao.getCustomerData(newHashedPassword);
		return customerDao.updatePassword(newUpdatedPasswordSalt, newUpdatedPasswordSalt);
	}

	@Override
	public List<CustomerProjection> getAllCustomers() {
        // Fetch customer projections using the DAO
        return customerDao.getAllCustomers();

}

	@Override
	public int productCount() {
		return customerDao.productCount();
	}

	@Override
	public int categoryCount() {
		return customerDao.categoryCount();
	}

	@Override
	public int orderCount() {
		return customerDao.orderCount();
	}
}
