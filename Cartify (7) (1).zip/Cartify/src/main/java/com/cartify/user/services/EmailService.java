package com.cartify.user.services;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

    @Autowired
    private JavaMailSender javaMailSender;

    public void sendEmail(String toEmail, String subject, String messageBody) throws Exception {
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom("harjotkaur291002@gmail.com");  // The email you want to send from
            message.setTo(toEmail);
            message.setSubject(subject);
            message.setText(messageBody);

            javaMailSender.send(message);
        } catch (Exception e) {
            System.err.println("SubAdmin created but email sending failed: " + e.getMessage());
            e.printStackTrace();
            throw new Exception("Failed to send email after SubAdmin creation", e);
        }
    }
}



