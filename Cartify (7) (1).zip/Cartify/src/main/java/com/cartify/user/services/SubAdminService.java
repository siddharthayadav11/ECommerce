package com.cartify.user.services;

import java.sql.SQLException;
import java.util.List;
import java.util.Optional;


import com.cartify.user.entities.SubAdmin;
import com.cartify.user.entities.SubadminProjection;

public interface SubAdminService {


	 void createSubAdmin(SubAdmin subAdmin) throws Exception;

	

	  public List<SubadminProjection> getAllSubadmins();



	SubAdmin getSubAdminDetails();



	void updateSubAdminDetails(SubAdmin subAdmin);


	public String getAuthorizationStatusByEmail(String email);  
	 public boolean updateAuthorizationStatus(String email, int newStatus);
	 public SubadminProjection findSubadminByEmail(String email);



	boolean toggleAuthorization(String email);
	 

}