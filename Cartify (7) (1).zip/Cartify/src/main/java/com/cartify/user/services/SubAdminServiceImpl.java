package com.cartify.user.services;

import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;


import com.cartify.user.entities.SubAdmin;
import com.cartify.user.entities.SubadminProjection;
import com.cartify.user.repository.SubAdminDao;

import com.cartify.utils.Utils;

import org.springframework.transaction.annotation.Transactional;

@Service
public class SubAdminServiceImpl implements SubAdminService {

    private final SubAdminDao subAdminDao;
    private final EmailService emailService;

    // Constructor to initialize DAO and EmailService
    public SubAdminServiceImpl(SubAdminDao subAdminDao, EmailService emailService) {
        this.subAdminDao = subAdminDao;
        this.emailService = emailService;
    }

    @Override
    @Transactional
    public void createSubAdmin(SubAdmin subAdmin) throws Exception {
        // Check if the email already exists before inserting
        if (subAdminDao.existsByEmail(subAdmin.getEmail())) {
            throw new Exception("Email already in use.");
        }

        // Save the plaintext password provided by the admin
        String plainPassword = subAdmin.getPassword();

        // Generate a salt and hash the password
        String salt = Utils.generateSalt(); // Use generateSalt method from Utils
        String saltedPassword =  plainPassword+salt; // Concatenate salt and password
        String hashedPassword = Utils.generatePwdHash(saltedPassword); // Hash the salted password

        // Ensure the SubAdmin object has the hashed password and salt
        subAdmin.setPwdSalt(salt); // Assuming you have a field for salt
        subAdmin.setPwdHash(hashedPassword); // Assuming you have a field for hashed password

        // Debugging: Log the salt and hash to ensure they are not null
        System.out.println("Generated Salt: " + salt);
        System.out.println("Generated Hashed Password: " + hashedPassword);

        // Insert the SubAdmin record into the database
        subAdminDao.createSubAdmin(subAdmin);

        try {
            // Send email with credentials
            String subject = "Welcome to Cartify - SubAdmin Credentials";
            String body = "Dear " + subAdmin.getFullName() + ",\n\n"
                    + "You have been created as a SubAdmin. Here are your credentials:\n\n"
                    + "Username: " + subAdmin.getEmail() + "\n"
                    + "Password: " + plainPassword + "\n\n"
                    + "Please login and change your password after your first login.\n\n"
                    + "Best regards,\nCartify Team";

            emailService.sendEmail(subAdmin.getEmail(), subject, body);
            System.out.println("SubAdmin created and email sent successfully!");
        } catch (Exception e) {
            System.err.println("SubAdmin created but email sending failed: " + e.getMessage());
            e.printStackTrace();
            throw new Exception("Failed to send email after SubAdmin creation");
        }
    }

	
	 public List<SubadminProjection> getAllSubadmins() {
	        return subAdminDao.getAllSubadmins();
	    }

	@Override
	public SubAdmin getSubAdminDetails() {
		return subAdminDao.getSubAdminDetails();
		
	}

	@Override
	public void updateSubAdminDetails(SubAdmin subAdmin) {
		 subAdminDao.updateSubAdminDetails(subAdmin);
	}
	
	@Override
    public String getAuthorizationStatusByEmail(String email) {
        // Fetch the current authorization status from the database
        int status = subAdminDao.getAuthorizationStatusByEmail(email);

        if (status == -1) {
            return "Subadmin not found!";
        }
        return status == 1 ? "Active" : "Revoked";
    }

    // Find subadmin details by email
    @Override
    public SubadminProjection findSubadminByEmail(String email) {
        // Fetch subadmin details by email
        return subAdminDao.findByEmail(email);
    }

    // Update the authorization status of a subadmin
    @Override
    public boolean updateAuthorizationStatus(String email, int newStatus) {
        // Fetch subadmin details by email
        SubadminProjection subadmin = subAdminDao.findByEmail(email);

        if (subadmin == null) {
            return false; // Subadmin not found
        }

        // If the status is already the same, no update is needed
        if (subadmin.getAuthorized() == newStatus) {
            return true; // No change in the status, so no update is needed
        }

        // Now update the authorization status in the database
        return subAdminDao.updateAuthorizationStatus(email, newStatus);
    }

    // Toggle the authorization status (i.e., Active -> Revoked or Revoked -> Active)
    @Override
    public boolean toggleAuthorization(String email) {
        // Fetch the current authorization status
        SubadminProjection subadmin = subAdminDao.findByEmail(email);

        if (subadmin == null) {
            return false; // Subadmin not found
        }

        // Toggle the authorization status (1 becomes 0, 0 becomes 1)
        int newStatus = subadmin.getAuthorized() == 1 ? 0 : 1;

        // Update the status in the database
        return subAdminDao.updateAuthorizationStatus(email, newStatus);
    }
}