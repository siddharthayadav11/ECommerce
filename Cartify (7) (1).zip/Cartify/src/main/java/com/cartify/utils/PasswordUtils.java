package com.cartify.utils;

import java.security.MessageDigest;
import java.util.Base64;

public class PasswordUtils {

    public static boolean verifyPassword(String inputPassword, String storedHash, String storedSalt) {
        try {
            // Concatenate salt and input password
            String saltedPassword = storedSalt + inputPassword;
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = md.digest(saltedPassword.getBytes());
            
            // Generate the Base64 encoded hash
            String computedHash = Base64.getEncoder().encodeToString(hashBytes);
            
            // Return whether the hashes match
            return computedHash.equals(storedHash);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}

