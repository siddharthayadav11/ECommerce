package com.cartify.utils;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Base64;

import org.springframework.web.multipart.MultipartFile;



public class Utils {

	public static String generateSalt() {

		String characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

		StringBuilder randomString = new StringBuilder(10);

		SecureRandom random = new SecureRandom();

		for (int i = 0; i < 10; i++) {

			int randomIndex = random.nextInt(characters.length());
			randomString.append(characters.charAt(randomIndex));

		}

		return randomString.toString();

	}

	public static String generatePwdHash(String inputString) {
	    String strHash = "";
	    try {
	        MessageDigest digest = MessageDigest.getInstance("SHA-256");
	        byte[] hashBytes = digest.digest(inputString.getBytes("UTF-8"));  // Make sure to use UTF-8 encoding

	        strHash = bytesToHex(hashBytes);
	    } catch (NoSuchAlgorithmException | UnsupportedEncodingException e) {
	        e.printStackTrace();
	    }
	    return strHash;
	}


	
	private static String bytesToHex(byte[] bytes) {
		StringBuilder hexString = new StringBuilder(2 * bytes.length);
		for (byte b : bytes) {
			String hex = Integer.toHexString(0xff & b);
			if (hex.length() == 1) {
				hexString.append('0');
			}
			hexString.append(hex);
		}
		return hexString.toString();
	}
	

	
	public static String getBase64Image(MultipartFile image) {
		try {
			byte[] imageBytes = image.getBytes();
			return Base64.getEncoder().encodeToString(imageBytes);
		}catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	



}
