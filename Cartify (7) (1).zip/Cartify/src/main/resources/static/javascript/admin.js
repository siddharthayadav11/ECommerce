document.addEventListener('DOMContentLoaded', () => {
           const ctx = document.getElementById('salesChart').getContext('2d');
           const salesChart = new Chart(ctx, {
               type: 'bar',
               data: {
                   labels: ['January', 'February', 'March', 'April'],
                   datasets: [{
                       label: 'Sales',
                       data: [1200, 1900, 3000, 5000],
                       backgroundColor: '#ffc107'
                   }]
               },
               options: {
                   responsive: true,
                   plugins: {
                       legend: { display: false }
                   }
               }
           });
       });