function validatePassword() {
            const password = document.getElementById("password").value;

            // Validation conditions
            const capitalLetter = /[A-Z]/.test(password);
            const smallLetter = /[a-z]/.test(password);
            const number = /\d/.test(password);
            const specialChar = /[@$!%*?&]/.test(password);
            const length = password.length >= 8 && password.length <= 16;

            // Update validation messages
            document.getElementById("capitalLetter").textContent = capitalLetter ? "✔ 1 Capital letter" : "✘ 1 Capital letter";
            document.getElementById("capitalLetter").className = capitalLetter ? "validation-message success" : "validation-message error";

            document.getElementById("smallLetter").textContent = smallLetter ? "✔ 1 Small letter" : "✘ 1 Small letter";
            document.getElementById("smallLetter").className = smallLetter ? "validation-message success" : "validation-message error";

            document.getElementById("number").textContent = number ? "✔ 1 Number" : "✘ 1 Number";
            document.getElementById("number").className = number ? "validation-message success" : "validation-message error";

            document.getElementById("specialChar").textContent = specialChar ? "✔ 1 Special character" : "✘ 1 Special character";
            document.getElementById("specialChar").className = specialChar ? "validation-message success" : "validation-message error";

            document.getElementById("length").textContent = length ? "✔ Length 8-16 characters" : "✘ Length 8-16 characters";
            document.getElementById("length").className = length ? "validation-message success" : "validation-message error";
        }

        function validateForm() {
            const email = document.getElementById("email").value.trim();
            const password = document.getElementById("password").value.trim();
            const emailError = document.getElementById("emailError");

            emailError.textContent = "";

            // Email validation
            if (email === "") {
                emailError.textContent = "Email is required.";
                emailError.className = "validation-message error";
                return false;
            } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
                emailError.textContent = "Invalid email format.";
                emailError.className = "validation-message error";
                return false;
            }

            // Password validation
            const capitalLetter = /[A-Z]/.test(password);
            const smallLetter = /[a-z]/.test(password);
            const number = /\d/.test(password);
            const specialChar = /[@$!%*?&]/.test(password);
            const length = password.length >= 8 && password.length <= 16;

            if (capitalLetter && smallLetter && number && specialChar && length) {
                alert("Login successful! Welcome.");
                return true;
            } else {
                alert("Please check the password requirements.");
                return false;
            }
        }