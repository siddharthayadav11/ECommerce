let generatedOTP;

        // Function to generate OTP
        function generateOTP() {
            const phone = document.getElementById("phone").value.trim();

            if (!/^\d{10}$/.test(phone)) {
                document.getElementById("phoneError").textContent = "Enter a valid 10-digit phone number.";
                return;
            }

            generatedOTP = Math.floor(100000 + Math.random() * 900000);
            alert(`Your OTP is: ${generatedOTP}`); // Simulating OTP sent to phone
            document.getElementById("otpSection").classList.remove("d-none");
        }

        // Function to verify OTP
        function verifyOTP() {
            const otp = document.getElementById("otp").value.trim();

            if (otp == generatedOTP) {
                alert("OTP verified successfully!");
                document.getElementById("passwordSection").classList.remove("d-none");
                document.getElementById("confirmPasswordSection").classList.remove("d-none");
                document.getElementById("registerButton").classList.remove("d-none");
            } else {
                document.getElementById("otpError").textContent = "Invalid OTP. Please try again.";
            }
        }

        // Form submission
        document.getElementById("registrationForm").addEventListener("submit", (event) => {
            event.preventDefault();

            const firstName = document.getElementById("firstName").value.trim();
            const middleName = document.getElementById("middleName").value.trim();
            const lastName = document.getElementById("lastName").value.trim();
            const phone = document.getElementById("phone").value.trim();
            const password = document.getElementById("password").value.trim();
            const confirmPassword = document.getElementById("confirmPassword").value.trim();

            // Validate password match
            if (password !== confirmPassword) {
                alert("Passwords do not match. Please try again.");
                return;
            }

            // Validate password strength
            const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,16}$/;
            if (!passwordRegex.test(password)) {
                alert("Password does not meet the requirements.");
                return;
            }

            // Show confirmation popup
            const details = `
                First Name: ${firstName}\n
                Middle Name: ${middleName || "N/A"}\n
                Last Name: ${lastName}\n
                Phone: ${phone}\n
            `;
            const confirmation = confirm(`You have entered the following details:\n\n${details}\nClick OK to submit.`);

            if (confirmation) {
                alert("Registered successfully!");
                window.location.href = "login.html";
            }
        });