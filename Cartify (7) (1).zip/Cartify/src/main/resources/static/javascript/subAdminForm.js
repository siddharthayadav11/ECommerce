// JavaScript for form validation
document.getElementById('subAdminForm').addEventListener('submit', function (event) {
    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value.trim();

    let isValid = true;
    let errorMessage = '';

    // Validate name
    if (name === '') {
        isValid = false;
        errorMessage += 'Name is required.\n';
    }

    // Validate email
    const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    if (!emailPattern.test(email)) {
        isValid = false;
        errorMessage += 'Please enter a valid email.\n';
    }

    // Validate password (e.g., minimum 6 characters)
    if (password.length < 8) {
        isValid = false;
        errorMessage += 'Password must be at least 8 characters long.\n';
    }

    // If invalid, prevent form submission and alert errors
    if (!isValid) {
        event.preventDefault();
        alert(errorMessage);
    }
});

// Function to toggle password visibility
const togglePassword = document.getElementById('togglePassword');
const passwordField = document.getElementById('password');

togglePassword.addEventListener('click', () => {
    const type = passwordField.getAttribute('type') === 'password' ? 'text' : 'password';
    passwordField.setAttribute('type', type);

    // Toggle text between "Show" and "Hide"
    togglePassword.textContent = type === 'password' ? 'Show' : 'Hide';
});
