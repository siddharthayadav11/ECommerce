import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cartify.user.entities.Customer;

@WebServlet("/loginServlet")
public class LoginServlet extends HttpServlet {
    protected void doPost(jakarta.servlet.http.HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String username = request.getParameter("email");
        String password = request.getParameter("password");
        Customer customer = request.getParameter("customer");

        
        if ("email".equals(email) && "password".equals(password)) {
            HttpSession session = request.getSession();
            session.setAttribute("email", email);
            response.sendRedirect("/customer/profile");
            Customer customer = request.getParameter("customer");
        } else {
            response.getWriter().println("Invalid login. Please try again.");
        }
    }
}
