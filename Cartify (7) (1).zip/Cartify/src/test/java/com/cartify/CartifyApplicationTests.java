package com.cartify;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CartifyApplicationTests {

	@Test
	void contextLoads() {
	}

}
