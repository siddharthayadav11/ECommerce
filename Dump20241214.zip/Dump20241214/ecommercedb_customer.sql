-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: ecommercedb
-- ------------------------------------------------------
-- Server version	8.0.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `full_name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `pwd_salt` varchar(50) NOT NULL,
  `pwd_hash` varchar(64) NOT NULL,
  `role_id` int NOT NULL,
  `mobile` varchar(15) DEFAULT NULL,
  `authorized` varchar(30) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES (1,'Harjot','harjotkaur291002@gmail.com','4O2U6chGSN','35aeeff31d1cc9d00eff43fd297e4fbdfebc90480b9e1f0784050391e441f5b9',3,'8957113713','1','2024-12-03 13:09:47'),(2,'random user','randomuser@gmail.com','cLNOE80ve5','d1aac0b9d91ca4b3a9a0b90730789f971cc20fc077b2f148f4ee7fb4875b8873',3,'9876546783','1','2024-12-03 13:17:57'),(3,'Kaustubh','superadmin@gmail.com','GpdM1rkiJv','c6be3cc907fc7f45878d4bc75343c914754c3c772c300288d5d4b52cdf3b3fb1',1,'8967545656','1','2024-12-03 13:22:30'),(4,'ironman','ironman@29','GpdM1rkiJv','c6be3cc907fc7f45878d4bc75343c914754c3c772c300288d5d4b52cdf3b3fb1',3,'9857430212','1','2024-12-03 13:31:51'),(7,'Anmol Chauhan','anmol@gmail.com','Y1bT3LgsAq','ff888b958eecd8bb2405580f383c64037222293f96979cdbdaab7cb341f7d52e',3,'7685684384','1','2024-12-05 15:43:42'),(9,'Harjot Arora','harjotkaur8957@gmail.com','yLr2L6Tb76','6d07ccace3f8c79ac0244c0b480431c1e30686749e75fc2d45bc4d56cbbf28a2',2,'9976567545','1','2024-12-06 10:50:54'),(10,'Ashu','ashu@gmail.com','LvHu6VfbNt','38459e31495a37d269d39fc847ea1db29bc68f6d79503582fe6422958b999b15',3,'8975643821','1','2024-12-09 12:17:10');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-14 21:01:13
